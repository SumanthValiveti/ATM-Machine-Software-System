﻿namespace ATM_New
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            LoginPage = new TableLayoutPanel();
            WelcomeLabel = new Label();
            Credentials = new TableLayoutPanel();
            Customer_L = new Label();
            Pin_L = new Label();
            CustomerT = new TextBox();
            PinT = new TextBox();
            Login_B = new Button();
            Mainmenu = new TableLayoutPanel();
            Services_L = new Label();
            Withdraw_B = new Button();
            Deposit_B = new Button();
            Transfer_B = new Button();
            Check_B = new Button();
            Logout_B = new Button();
            Withdraw = new TableLayoutPanel();
            accList = new ListBox();
            return_B = new Button();
            accSelect_L = new Label();
            AlertPage = new TableLayoutPanel();
            Continue_B = new Button();
            Alert_L = new Label();
            Enter_Page = new TableLayoutPanel();
            Clear_Page = new TableLayoutPanel();
            Continue2_B = new Button();
            Backspace_Page = new TableLayoutPanel();
            Backspace_B = new Button();
            Clear_B = new Button();
            Return2_B = new Button();
            Num_Page = new TableLayoutPanel();
            Num1Page = new TableLayoutPanel();
            button5 = new Button();
            button4 = new Button();
            button3 = new Button();
            button2 = new Button();
            b_1 = new Button();
            Num2Page = new TableLayoutPanel();
            b_0 = new Button();
            button9 = new Button();
            button8 = new Button();
            button7 = new Button();
            button6 = new Button();
            Entering = new TableLayoutPanel();
            EnterAmt_L = new Label();
            EnterAmt_T = new TextBox();
            InsufficientAlert = new TableLayoutPanel();
            label1 = new Label();
            Continue_3B = new Button();
            AlertBalance = new TableLayoutPanel();
            label2 = new Label();
            Return3_B = new Button();
            CollectAlert = new TableLayoutPanel();
            Continue4_B = new Button();
            label3 = new Label();
            TransferPage = new TableLayoutPanel();
            Return4_B = new Button();
            label4 = new Label();
            listBox1 = new ListBox();
            DepositPage = new TableLayoutPanel();
            listBox2 = new ListBox();
            Return5_B = new Button();
            label5 = new Label();
            CheckPage = new TableLayoutPanel();
            listBox3 = new ListBox();
            Return6_B = new Button();
            label6 = new Label();
            tableLayoutPanel1 = new TableLayoutPanel();
            button1 = new Button();
            label7 = new Label();
            tableLayoutPanel2 = new TableLayoutPanel();
            button10 = new Button();
            label8 = new Label();
            BalanceAlert = new TableLayoutPanel();
            Return7_B = new Button();
            label9 = new Label();
            LoginAlert = new TableLayoutPanel();
            Continue5_B = new Button();
            label10 = new Label();
            LogoutConformation = new TableLayoutPanel();
            Cancel_B = new Button();
            Exit_B = new Button();
            tableLayoutPanel3 = new TableLayoutPanel();
            tableLayoutPanel4 = new TableLayoutPanel();
            button11 = new Button();
            tableLayoutPanel5 = new TableLayoutPanel();
            button12 = new Button();
            button13 = new Button();
            button14 = new Button();
            tableLayoutPanel6 = new TableLayoutPanel();
            tableLayoutPanel7 = new TableLayoutPanel();
            button15 = new Button();
            button16 = new Button();
            button17 = new Button();
            button18 = new Button();
            button19 = new Button();
            tableLayoutPanel8 = new TableLayoutPanel();
            button20 = new Button();
            button21 = new Button();
            button22 = new Button();
            button23 = new Button();
            button24 = new Button();
            tableLayoutPanel9 = new TableLayoutPanel();
            label11 = new Label();
            textBox1 = new TextBox();
            EnterPageDeposit = new TableLayoutPanel();
            tableLayoutPanel11 = new TableLayoutPanel();
            button25 = new Button();
            tableLayoutPanel12 = new TableLayoutPanel();
            button26 = new Button();
            button27 = new Button();
            button28 = new Button();
            tableLayoutPanel13 = new TableLayoutPanel();
            tableLayoutPanel14 = new TableLayoutPanel();
            button29 = new Button();
            button30 = new Button();
            button31 = new Button();
            button32 = new Button();
            button33 = new Button();
            tableLayoutPanel15 = new TableLayoutPanel();
            button34 = new Button();
            button35 = new Button();
            button36 = new Button();
            button37 = new Button();
            button38 = new Button();
            tableLayoutPanel16 = new TableLayoutPanel();
            label12 = new Label();
            textBox2 = new TextBox();
            tableLayoutPanel10 = new TableLayoutPanel();
            button39 = new Button();
            label13 = new Label();
            DepositAlert = new TableLayoutPanel();
            Return_Deposit = new Button();
            label14 = new Label();
            Enter_Page2 = new TableLayoutPanel();
            tableLayoutPanel18 = new TableLayoutPanel();
            button40 = new Button();
            tableLayoutPanel19 = new TableLayoutPanel();
            button41 = new Button();
            button42 = new Button();
            button43 = new Button();
            tableLayoutPanel20 = new TableLayoutPanel();
            tableLayoutPanel21 = new TableLayoutPanel();
            button44 = new Button();
            button45 = new Button();
            button46 = new Button();
            button47 = new Button();
            button48 = new Button();
            tableLayoutPanel22 = new TableLayoutPanel();
            button49 = new Button();
            button50 = new Button();
            button51 = new Button();
            button52 = new Button();
            button53 = new Button();
            tableLayoutPanel23 = new TableLayoutPanel();
            label15 = new Label();
            textBox3 = new TextBox();
            TransferAlert = new TableLayoutPanel();
            button54 = new Button();
            label16 = new Label();
            TransferPage2 = new TableLayoutPanel();
            button55 = new Button();
            label17 = new Label();
            listBox4 = new ListBox();
            LoginPage.SuspendLayout();
            Credentials.SuspendLayout();
            Mainmenu.SuspendLayout();
            Withdraw.SuspendLayout();
            AlertPage.SuspendLayout();
            Enter_Page.SuspendLayout();
            Clear_Page.SuspendLayout();
            Backspace_Page.SuspendLayout();
            Num_Page.SuspendLayout();
            Num1Page.SuspendLayout();
            Num2Page.SuspendLayout();
            Entering.SuspendLayout();
            InsufficientAlert.SuspendLayout();
            AlertBalance.SuspendLayout();
            CollectAlert.SuspendLayout();
            TransferPage.SuspendLayout();
            DepositPage.SuspendLayout();
            CheckPage.SuspendLayout();
            tableLayoutPanel1.SuspendLayout();
            tableLayoutPanel2.SuspendLayout();
            BalanceAlert.SuspendLayout();
            LoginAlert.SuspendLayout();
            LogoutConformation.SuspendLayout();
            tableLayoutPanel3.SuspendLayout();
            tableLayoutPanel4.SuspendLayout();
            tableLayoutPanel5.SuspendLayout();
            tableLayoutPanel6.SuspendLayout();
            tableLayoutPanel7.SuspendLayout();
            tableLayoutPanel8.SuspendLayout();
            tableLayoutPanel9.SuspendLayout();
            EnterPageDeposit.SuspendLayout();
            tableLayoutPanel11.SuspendLayout();
            tableLayoutPanel12.SuspendLayout();
            tableLayoutPanel13.SuspendLayout();
            tableLayoutPanel14.SuspendLayout();
            tableLayoutPanel15.SuspendLayout();
            tableLayoutPanel16.SuspendLayout();
            tableLayoutPanel10.SuspendLayout();
            DepositAlert.SuspendLayout();
            Enter_Page2.SuspendLayout();
            tableLayoutPanel18.SuspendLayout();
            tableLayoutPanel19.SuspendLayout();
            tableLayoutPanel20.SuspendLayout();
            tableLayoutPanel21.SuspendLayout();
            tableLayoutPanel22.SuspendLayout();
            tableLayoutPanel23.SuspendLayout();
            TransferAlert.SuspendLayout();
            TransferPage2.SuspendLayout();
            SuspendLayout();
            // 
            // LoginPage
            // 
            LoginPage.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            LoginPage.ColumnCount = 1;
            LoginPage.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            LoginPage.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 20F));
            LoginPage.Controls.Add(WelcomeLabel, 0, 0);
            LoginPage.Controls.Add(Credentials, 0, 1);
            LoginPage.Controls.Add(Login_B, 0, 2);
            LoginPage.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            LoginPage.Location = new Point(12, 13);
            LoginPage.Name = "LoginPage";
            LoginPage.RowCount = 3;
            LoginPage.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            LoginPage.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            LoginPage.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            LoginPage.Size = new Size(1531, 667);
            LoginPage.TabIndex = 0;
            // 
            // WelcomeLabel
            // 
            WelcomeLabel.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            WelcomeLabel.AutoSize = true;
            WelcomeLabel.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            WelcomeLabel.Location = new Point(3, 0);
            WelcomeLabel.Name = "WelcomeLabel";
            WelcomeLabel.Size = new Size(1525, 166);
            WelcomeLabel.TabIndex = 0;
            WelcomeLabel.Text = "Welcome To ZZZ Bank";
            WelcomeLabel.TextAlign = ContentAlignment.MiddleCenter;
            WelcomeLabel.Click += Label1_Click;
            // 
            // Credentials
            // 
            Credentials.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            Credentials.BackColor = Color.FromArgb(255, 128, 0);
            Credentials.ColumnCount = 2;
            Credentials.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            Credentials.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            Credentials.Controls.Add(Customer_L, 0, 0);
            Credentials.Controls.Add(Pin_L, 0, 1);
            Credentials.Controls.Add(CustomerT, 1, 0);
            Credentials.Controls.Add(PinT, 1, 1);
            Credentials.ForeColor = Color.FromArgb(128, 64, 64);
            Credentials.Location = new Point(3, 169);
            Credentials.Name = "Credentials";
            Credentials.RowCount = 2;
            Credentials.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            Credentials.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            Credentials.Size = new Size(1525, 327);
            Credentials.TabIndex = 1;
            // 
            // Customer_L
            // 
            Customer_L.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            Customer_L.AutoSize = true;
            Customer_L.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            Customer_L.Location = new Point(3, 0);
            Customer_L.Name = "Customer_L";
            Customer_L.Size = new Size(756, 163);
            Customer_L.TabIndex = 0;
            Customer_L.Text = "Customer ID";
            Customer_L.TextAlign = ContentAlignment.BottomRight;
            // 
            // Pin_L
            // 
            Pin_L.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            Pin_L.AutoSize = true;
            Pin_L.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            Pin_L.Location = new Point(3, 163);
            Pin_L.Name = "Pin_L";
            Pin_L.Size = new Size(756, 164);
            Pin_L.TabIndex = 1;
            Pin_L.Text = "PIN";
            Pin_L.TextAlign = ContentAlignment.TopRight;
            // 
            // CustomerT
            // 
            CustomerT.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            CustomerT.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            CustomerT.Location = new Point(765, 117);
            CustomerT.Name = "CustomerT";
            CustomerT.Size = new Size(190, 43);
            CustomerT.TabIndex = 2;
            // 
            // PinT
            // 
            PinT.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            PinT.Location = new Point(765, 166);
            PinT.Name = "PinT";
            PinT.Size = new Size(190, 43);
            PinT.TabIndex = 3;
            // 
            // Login_B
            // 
            Login_B.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            Login_B.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            Login_B.Location = new Point(3, 502);
            Login_B.Name = "Login_B";
            Login_B.Size = new Size(1525, 162);
            Login_B.TabIndex = 2;
            Login_B.Text = "Login";
            Login_B.UseVisualStyleBackColor = true;
            Login_B.Click += Login_B_Click;
            // 
            // Mainmenu
            // 
            Mainmenu.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            Mainmenu.ColumnCount = 1;
            Mainmenu.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            Mainmenu.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 20F));
            Mainmenu.Controls.Add(Services_L, 0, 0);
            Mainmenu.Controls.Add(Withdraw_B, 0, 1);
            Mainmenu.Controls.Add(Deposit_B, 0, 2);
            Mainmenu.Controls.Add(Transfer_B, 0, 3);
            Mainmenu.Controls.Add(Check_B, 0, 4);
            Mainmenu.Controls.Add(Logout_B, 0, 5);
            Mainmenu.Location = new Point(12, 12);
            Mainmenu.Name = "Mainmenu";
            Mainmenu.RowCount = 6;
            Mainmenu.RowStyles.Add(new RowStyle(SizeType.Percent, 16.6666679F));
            Mainmenu.RowStyles.Add(new RowStyle(SizeType.Percent, 16.6666679F));
            Mainmenu.RowStyles.Add(new RowStyle(SizeType.Percent, 16.6666679F));
            Mainmenu.RowStyles.Add(new RowStyle(SizeType.Percent, 16.6666679F));
            Mainmenu.RowStyles.Add(new RowStyle(SizeType.Percent, 16.6666679F));
            Mainmenu.RowStyles.Add(new RowStyle(SizeType.Percent, 16.6666679F));
            Mainmenu.Size = new Size(1528, 668);
            Mainmenu.TabIndex = 1;
            Mainmenu.Visible = false;
            // 
            // Services_L
            // 
            Services_L.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            Services_L.AutoSize = true;
            Services_L.BackColor = Color.FromArgb(255, 128, 0);
            Services_L.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            Services_L.ForeColor = Color.FromArgb(128, 64, 64);
            Services_L.Location = new Point(3, 0);
            Services_L.Name = "Services_L";
            Services_L.Size = new Size(1522, 111);
            Services_L.TabIndex = 0;
            Services_L.Text = "Please Select one of the Following Services:";
            Services_L.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // Withdraw_B
            // 
            Withdraw_B.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            Withdraw_B.BackColor = Color.FromArgb(255, 128, 0);
            Withdraw_B.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            Withdraw_B.ForeColor = Color.FromArgb(128, 64, 64);
            Withdraw_B.Location = new Point(3, 114);
            Withdraw_B.Name = "Withdraw_B";
            Withdraw_B.Size = new Size(1522, 105);
            Withdraw_B.TabIndex = 1;
            Withdraw_B.Text = "Withdraw Money";
            Withdraw_B.UseVisualStyleBackColor = false;
            Withdraw_B.Click += Withdraw_B_Click;
            // 
            // Deposit_B
            // 
            Deposit_B.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            Deposit_B.BackColor = Color.FromArgb(255, 128, 0);
            Deposit_B.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            Deposit_B.ForeColor = Color.FromArgb(128, 64, 64);
            Deposit_B.Location = new Point(3, 225);
            Deposit_B.Name = "Deposit_B";
            Deposit_B.Size = new Size(1522, 105);
            Deposit_B.TabIndex = 2;
            Deposit_B.Text = "Deposit Money";
            Deposit_B.UseVisualStyleBackColor = false;
            Deposit_B.Click += Deposit_B_Click;
            // 
            // Transfer_B
            // 
            Transfer_B.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            Transfer_B.BackColor = Color.FromArgb(255, 128, 0);
            Transfer_B.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            Transfer_B.ForeColor = Color.FromArgb(128, 64, 64);
            Transfer_B.Location = new Point(3, 336);
            Transfer_B.Name = "Transfer_B";
            Transfer_B.Size = new Size(1522, 105);
            Transfer_B.TabIndex = 3;
            Transfer_B.Text = "Transfer Money";
            Transfer_B.UseVisualStyleBackColor = false;
            Transfer_B.Click += Transfer_B_Click;
            // 
            // Check_B
            // 
            Check_B.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            Check_B.BackColor = Color.FromArgb(255, 128, 0);
            Check_B.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            Check_B.ForeColor = Color.FromArgb(128, 64, 64);
            Check_B.Location = new Point(3, 447);
            Check_B.Name = "Check_B";
            Check_B.Size = new Size(1522, 105);
            Check_B.TabIndex = 4;
            Check_B.Text = "Check Balance";
            Check_B.UseVisualStyleBackColor = false;
            Check_B.Click += Check_B_Click;
            // 
            // Logout_B
            // 
            Logout_B.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            Logout_B.BackColor = Color.FromArgb(255, 128, 0);
            Logout_B.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            Logout_B.ForeColor = Color.FromArgb(128, 64, 64);
            Logout_B.Location = new Point(3, 558);
            Logout_B.Name = "Logout_B";
            Logout_B.Size = new Size(1522, 107);
            Logout_B.TabIndex = 5;
            Logout_B.Text = "Logout";
            Logout_B.UseVisualStyleBackColor = false;
            Logout_B.Click += Logout_B_Click;
            // 
            // Withdraw
            // 
            Withdraw.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            Withdraw.ColumnCount = 1;
            Withdraw.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            Withdraw.Controls.Add(accList, 0, 1);
            Withdraw.Controls.Add(return_B, 0, 2);
            Withdraw.Controls.Add(accSelect_L, 0, 0);
            Withdraw.Location = new Point(12, 13);
            Withdraw.Name = "Withdraw";
            Withdraw.RowCount = 3;
            Withdraw.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            Withdraw.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            Withdraw.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            Withdraw.Size = new Size(1531, 667);
            Withdraw.TabIndex = 2;
            Withdraw.Visible = false;
            Withdraw.Paint += TableLayoutPanel1_Paint;
            // 
            // accList
            // 
            accList.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            accList.BackColor = Color.FromArgb(255, 128, 0);
            accList.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            accList.ForeColor = Color.FromArgb(128, 64, 64);
            accList.FormattingEnabled = true;
            accList.ItemHeight = 37;
            accList.Location = new Point(3, 169);
            accList.Name = "accList";
            accList.Size = new Size(1525, 300);
            accList.TabIndex = 1;
            accList.SelectedIndexChanged += accList_SelectedIndexChanged;
            // 
            // return_B
            // 
            return_B.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            return_B.BackColor = Color.FromArgb(255, 128, 0);
            return_B.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            return_B.ForeColor = Color.FromArgb(128, 64, 64);
            return_B.Location = new Point(3, 502);
            return_B.Name = "return_B";
            return_B.Size = new Size(1525, 162);
            return_B.TabIndex = 2;
            return_B.Text = "Return To Main Menu";
            return_B.UseVisualStyleBackColor = false;
            return_B.Click += return_B_Click;
            // 
            // accSelect_L
            // 
            accSelect_L.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            accSelect_L.AutoSize = true;
            accSelect_L.BackColor = Color.FromArgb(255, 128, 0);
            accSelect_L.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            accSelect_L.ForeColor = Color.FromArgb(128, 64, 64);
            accSelect_L.Location = new Point(3, 0);
            accSelect_L.Name = "accSelect_L";
            accSelect_L.Size = new Size(1525, 166);
            accSelect_L.TabIndex = 0;
            accSelect_L.Text = "Select an Account to Withdraw Money:";
            accSelect_L.TextAlign = ContentAlignment.MiddleCenter;
            accSelect_L.Click += Label1_Click_1;
            // 
            // AlertPage
            // 
            AlertPage.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            AlertPage.ColumnCount = 1;
            AlertPage.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            AlertPage.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 20F));
            AlertPage.Controls.Add(Continue_B, 0, 1);
            AlertPage.Controls.Add(Alert_L, 0, 0);
            AlertPage.Location = new Point(298, 48);
            AlertPage.Name = "AlertPage";
            AlertPage.RowCount = 2;
            AlertPage.RowStyles.Add(new RowStyle(SizeType.Percent, 70F));
            AlertPage.RowStyles.Add(new RowStyle(SizeType.Percent, 30F));
            AlertPage.Size = new Size(1017, 595);
            AlertPage.TabIndex = 3;
            AlertPage.Visible = false;
            // 
            // Continue_B
            // 
            Continue_B.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            Continue_B.BackColor = Color.FromArgb(255, 128, 0);
            Continue_B.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            Continue_B.ForeColor = Color.FromArgb(128, 64, 64);
            Continue_B.Location = new Point(3, 419);
            Continue_B.Name = "Continue_B";
            Continue_B.Size = new Size(1011, 173);
            Continue_B.TabIndex = 0;
            Continue_B.Text = "Continue";
            Continue_B.UseVisualStyleBackColor = false;
            // 
            // Alert_L
            // 
            Alert_L.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            Alert_L.AutoSize = true;
            Alert_L.BackColor = Color.FromArgb(255, 128, 0);
            Alert_L.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            Alert_L.ForeColor = Color.FromArgb(128, 64, 64);
            Alert_L.Location = new Point(3, 0);
            Alert_L.Name = "Alert_L";
            Alert_L.Size = new Size(1011, 416);
            Alert_L.TabIndex = 1;
            Alert_L.Text = "Alert!\r\n\r\nTransaction of Account have Exceeded!\r\n(Max.Limit. 3000$)";
            Alert_L.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // Enter_Page
            // 
            Enter_Page.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            Enter_Page.ColumnCount = 1;
            Enter_Page.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            Enter_Page.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 20F));
            Enter_Page.Controls.Add(Clear_Page, 0, 2);
            Enter_Page.Controls.Add(Return2_B, 0, 3);
            Enter_Page.Controls.Add(Num_Page, 0, 1);
            Enter_Page.Controls.Add(Entering, 0, 0);
            Enter_Page.Location = new Point(12, 13);
            Enter_Page.Name = "Enter_Page";
            Enter_Page.RowCount = 4;
            Enter_Page.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            Enter_Page.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            Enter_Page.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            Enter_Page.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            Enter_Page.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            Enter_Page.Size = new Size(1531, 676);
            Enter_Page.TabIndex = 4;
            Enter_Page.Visible = false;
            // 
            // Clear_Page
            // 
            Clear_Page.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            Clear_Page.BackColor = Color.White;
            Clear_Page.ColumnCount = 2;
            Clear_Page.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            Clear_Page.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            Clear_Page.Controls.Add(Continue2_B, 1, 0);
            Clear_Page.Controls.Add(Backspace_Page, 0, 0);
            Clear_Page.ForeColor = Color.Black;
            Clear_Page.Location = new Point(3, 341);
            Clear_Page.Name = "Clear_Page";
            Clear_Page.RowCount = 1;
            Clear_Page.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            Clear_Page.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            Clear_Page.Size = new Size(1525, 163);
            Clear_Page.TabIndex = 2;
            // 
            // Continue2_B
            // 
            Continue2_B.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            Continue2_B.BackColor = Color.FromArgb(255, 128, 0);
            Continue2_B.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            Continue2_B.ForeColor = Color.FromArgb(128, 64, 64);
            Continue2_B.Location = new Point(765, 3);
            Continue2_B.Name = "Continue2_B";
            Continue2_B.Size = new Size(757, 157);
            Continue2_B.TabIndex = 1;
            Continue2_B.Text = "Continue";
            Continue2_B.UseVisualStyleBackColor = false;
            Continue2_B.Click += Continue2_B_Click;
            // 
            // Backspace_Page
            // 
            Backspace_Page.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            Backspace_Page.BackColor = Color.White;
            Backspace_Page.ColumnCount = 2;
            Backspace_Page.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            Backspace_Page.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            Backspace_Page.Controls.Add(Backspace_B, 0, 0);
            Backspace_Page.Controls.Add(Clear_B, 1, 0);
            Backspace_Page.ForeColor = Color.Black;
            Backspace_Page.Location = new Point(3, 3);
            Backspace_Page.Name = "Backspace_Page";
            Backspace_Page.RowCount = 1;
            Backspace_Page.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            Backspace_Page.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            Backspace_Page.Size = new Size(756, 157);
            Backspace_Page.TabIndex = 2;
            // 
            // Backspace_B
            // 
            Backspace_B.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            Backspace_B.BackColor = Color.FromArgb(255, 128, 0);
            Backspace_B.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            Backspace_B.ForeColor = Color.FromArgb(128, 64, 64);
            Backspace_B.Location = new Point(3, 3);
            Backspace_B.Name = "Backspace_B";
            Backspace_B.Size = new Size(372, 151);
            Backspace_B.TabIndex = 0;
            Backspace_B.Text = "Backspace";
            Backspace_B.UseVisualStyleBackColor = false;
            Backspace_B.Click += Backspace_B_Click;
            // 
            // Clear_B
            // 
            Clear_B.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            Clear_B.BackColor = Color.FromArgb(255, 128, 0);
            Clear_B.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            Clear_B.ForeColor = Color.FromArgb(128, 64, 64);
            Clear_B.Location = new Point(381, 3);
            Clear_B.Name = "Clear_B";
            Clear_B.Size = new Size(372, 151);
            Clear_B.TabIndex = 1;
            Clear_B.Text = "Clear All";
            Clear_B.UseVisualStyleBackColor = false;
            Clear_B.Click += Clear_B_Click;
            // 
            // Return2_B
            // 
            Return2_B.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            Return2_B.BackColor = Color.FromArgb(255, 128, 0);
            Return2_B.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            Return2_B.ForeColor = Color.FromArgb(128, 64, 64);
            Return2_B.Location = new Point(3, 510);
            Return2_B.Name = "Return2_B";
            Return2_B.Size = new Size(1525, 163);
            Return2_B.TabIndex = 3;
            Return2_B.Text = "Return To Accounts";
            Return2_B.UseVisualStyleBackColor = false;
            Return2_B.Click += Return2_B_Click;
            // 
            // Num_Page
            // 
            Num_Page.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            Num_Page.BackColor = Color.White;
            Num_Page.ColumnCount = 2;
            Num_Page.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            Num_Page.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            Num_Page.Controls.Add(Num1Page, 0, 0);
            Num_Page.Controls.Add(Num2Page, 1, 0);
            Num_Page.ForeColor = Color.Black;
            Num_Page.Location = new Point(3, 172);
            Num_Page.Name = "Num_Page";
            Num_Page.RowCount = 1;
            Num_Page.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            Num_Page.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            Num_Page.Size = new Size(1525, 163);
            Num_Page.TabIndex = 0;
            // 
            // Num1Page
            // 
            Num1Page.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            Num1Page.BackColor = Color.White;
            Num1Page.ColumnCount = 5;
            Num1Page.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20F));
            Num1Page.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20F));
            Num1Page.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20F));
            Num1Page.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20F));
            Num1Page.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20F));
            Num1Page.Controls.Add(button5, 4, 0);
            Num1Page.Controls.Add(button4, 3, 0);
            Num1Page.Controls.Add(button3, 2, 0);
            Num1Page.Controls.Add(button2, 1, 0);
            Num1Page.Controls.Add(b_1, 0, 0);
            Num1Page.ForeColor = Color.Black;
            Num1Page.Location = new Point(3, 3);
            Num1Page.Name = "Num1Page";
            Num1Page.RowCount = 1;
            Num1Page.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            Num1Page.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            Num1Page.Size = new Size(756, 157);
            Num1Page.TabIndex = 1;
            // 
            // button5
            // 
            button5.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            button5.BackColor = Color.FromArgb(255, 128, 0);
            button5.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            button5.ForeColor = Color.FromArgb(128, 64, 64);
            button5.Location = new Point(607, 3);
            button5.Name = "button5";
            button5.Size = new Size(146, 151);
            button5.TabIndex = 0;
            button5.Text = "5";
            button5.UseVisualStyleBackColor = false;
            button5.Click += button5_Click;
            // 
            // button4
            // 
            button4.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            button4.BackColor = Color.FromArgb(255, 128, 0);
            button4.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            button4.ForeColor = Color.FromArgb(128, 64, 64);
            button4.Location = new Point(456, 3);
            button4.Name = "button4";
            button4.Size = new Size(145, 151);
            button4.TabIndex = 1;
            button4.Text = "4";
            button4.UseVisualStyleBackColor = false;
            button4.Click += button4_Click;
            // 
            // button3
            // 
            button3.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            button3.BackColor = Color.FromArgb(255, 128, 0);
            button3.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            button3.ForeColor = Color.FromArgb(128, 64, 64);
            button3.Location = new Point(305, 3);
            button3.Name = "button3";
            button3.Size = new Size(145, 151);
            button3.TabIndex = 2;
            button3.Text = "3";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // button2
            // 
            button2.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            button2.BackColor = Color.FromArgb(255, 128, 0);
            button2.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            button2.ForeColor = Color.FromArgb(128, 64, 64);
            button2.Location = new Point(154, 3);
            button2.Name = "button2";
            button2.Size = new Size(145, 151);
            button2.TabIndex = 3;
            button2.Text = "2";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // b_1
            // 
            b_1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            b_1.BackColor = Color.FromArgb(255, 128, 0);
            b_1.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            b_1.ForeColor = Color.FromArgb(128, 64, 64);
            b_1.Location = new Point(3, 3);
            b_1.Name = "b_1";
            b_1.Size = new Size(145, 151);
            b_1.TabIndex = 4;
            b_1.Text = "1";
            b_1.UseVisualStyleBackColor = false;
            b_1.Click += b_1_Click;
            // 
            // Num2Page
            // 
            Num2Page.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            Num2Page.BackColor = Color.White;
            Num2Page.ColumnCount = 5;
            Num2Page.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20F));
            Num2Page.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20F));
            Num2Page.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20F));
            Num2Page.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20F));
            Num2Page.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20F));
            Num2Page.Controls.Add(b_0, 4, 0);
            Num2Page.Controls.Add(button9, 3, 0);
            Num2Page.Controls.Add(button8, 2, 0);
            Num2Page.Controls.Add(button7, 1, 0);
            Num2Page.Controls.Add(button6, 0, 0);
            Num2Page.ForeColor = Color.Black;
            Num2Page.Location = new Point(765, 3);
            Num2Page.Name = "Num2Page";
            Num2Page.RowCount = 1;
            Num2Page.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            Num2Page.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            Num2Page.Size = new Size(757, 157);
            Num2Page.TabIndex = 0;
            // 
            // b_0
            // 
            b_0.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            b_0.BackColor = Color.FromArgb(255, 128, 0);
            b_0.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            b_0.ForeColor = Color.FromArgb(128, 64, 64);
            b_0.Location = new Point(607, 3);
            b_0.Name = "b_0";
            b_0.Size = new Size(147, 151);
            b_0.TabIndex = 0;
            b_0.Text = "0";
            b_0.UseVisualStyleBackColor = false;
            b_0.Click += b_0_Click;
            // 
            // button9
            // 
            button9.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            button9.BackColor = Color.FromArgb(255, 128, 0);
            button9.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            button9.ForeColor = Color.FromArgb(128, 64, 64);
            button9.Location = new Point(456, 3);
            button9.Name = "button9";
            button9.Size = new Size(145, 151);
            button9.TabIndex = 1;
            button9.Text = "9";
            button9.UseVisualStyleBackColor = false;
            button9.Click += button9_Click;
            // 
            // button8
            // 
            button8.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            button8.BackColor = Color.FromArgb(255, 128, 0);
            button8.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            button8.ForeColor = Color.FromArgb(128, 64, 64);
            button8.Location = new Point(305, 3);
            button8.Name = "button8";
            button8.Size = new Size(145, 151);
            button8.TabIndex = 2;
            button8.Text = "8";
            button8.UseVisualStyleBackColor = false;
            button8.Click += button8_Click;
            // 
            // button7
            // 
            button7.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            button7.BackColor = Color.FromArgb(255, 128, 0);
            button7.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            button7.ForeColor = Color.FromArgb(128, 64, 64);
            button7.Location = new Point(154, 3);
            button7.Name = "button7";
            button7.Size = new Size(145, 151);
            button7.TabIndex = 3;
            button7.Text = "7";
            button7.UseVisualStyleBackColor = false;
            button7.Click += button7_Click;
            // 
            // button6
            // 
            button6.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            button6.BackColor = Color.FromArgb(255, 128, 0);
            button6.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            button6.ForeColor = Color.FromArgb(128, 64, 64);
            button6.Location = new Point(3, 3);
            button6.Name = "button6";
            button6.Size = new Size(145, 151);
            button6.TabIndex = 4;
            button6.Text = "6";
            button6.UseVisualStyleBackColor = false;
            button6.Click += button6_Click;
            // 
            // Entering
            // 
            Entering.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            Entering.BackColor = Color.FromArgb(255, 128, 0);
            Entering.ColumnCount = 2;
            Entering.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            Entering.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            Entering.Controls.Add(EnterAmt_L, 0, 0);
            Entering.Controls.Add(EnterAmt_T, 1, 0);
            Entering.ForeColor = Color.FromArgb(128, 64, 64);
            Entering.Location = new Point(3, 3);
            Entering.Name = "Entering";
            Entering.RowCount = 1;
            Entering.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            Entering.Size = new Size(1525, 163);
            Entering.TabIndex = 1;
            // 
            // EnterAmt_L
            // 
            EnterAmt_L.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            EnterAmt_L.AutoSize = true;
            EnterAmt_L.BackColor = Color.FromArgb(255, 128, 0);
            EnterAmt_L.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            EnterAmt_L.ForeColor = Color.FromArgb(128, 64, 64);
            EnterAmt_L.Location = new Point(3, 0);
            EnterAmt_L.Name = "EnterAmt_L";
            EnterAmt_L.Size = new Size(756, 163);
            EnterAmt_L.TabIndex = 0;
            EnterAmt_L.Text = "Enter Amount to Withdraw:\r\n(max.$3000)";
            EnterAmt_L.TextAlign = ContentAlignment.MiddleCenter;
            EnterAmt_L.Click += EnterAmt_L_Click;
            // 
            // EnterAmt_T
            // 
            EnterAmt_T.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            EnterAmt_T.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            EnterAmt_T.Location = new Point(765, 60);
            EnterAmt_T.Name = "EnterAmt_T";
            EnterAmt_T.Size = new Size(757, 43);
            EnterAmt_T.TabIndex = 1;
            // 
            // InsufficientAlert
            // 
            InsufficientAlert.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            InsufficientAlert.ColumnCount = 1;
            InsufficientAlert.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            InsufficientAlert.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 20F));
            InsufficientAlert.Controls.Add(label1, 0, 0);
            InsufficientAlert.Controls.Add(Continue_3B, 0, 1);
            InsufficientAlert.Location = new Point(301, 83);
            InsufficientAlert.Name = "InsufficientAlert";
            InsufficientAlert.RowCount = 2;
            InsufficientAlert.RowStyles.Add(new RowStyle(SizeType.Percent, 75F));
            InsufficientAlert.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            InsufficientAlert.Size = new Size(938, 545);
            InsufficientAlert.TabIndex = 5;
            InsufficientAlert.Visible = false;
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label1.AutoSize = true;
            label1.BackColor = Color.FromArgb(255, 128, 0);
            label1.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            label1.ForeColor = Color.FromArgb(128, 64, 64);
            label1.Location = new Point(3, 0);
            label1.Name = "label1";
            label1.Size = new Size(932, 408);
            label1.TabIndex = 0;
            label1.Text = "Insufficient Funds!!!\r\n\r\nSelect Another Account or Enter Smaller Amount\r\n\r\n";
            label1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // Continue_3B
            // 
            Continue_3B.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            Continue_3B.BackColor = Color.FromArgb(255, 128, 0);
            Continue_3B.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            Continue_3B.ForeColor = Color.FromArgb(128, 64, 64);
            Continue_3B.Location = new Point(3, 411);
            Continue_3B.Name = "Continue_3B";
            Continue_3B.Size = new Size(932, 131);
            Continue_3B.TabIndex = 1;
            Continue_3B.Text = "Continue";
            Continue_3B.UseVisualStyleBackColor = false;
            Continue_3B.Click += Continue_3B_Click;
            // 
            // AlertBalance
            // 
            AlertBalance.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            AlertBalance.ColumnCount = 1;
            AlertBalance.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            AlertBalance.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 20F));
            AlertBalance.Controls.Add(label2, 0, 0);
            AlertBalance.Controls.Add(Return3_B, 0, 1);
            AlertBalance.Location = new Point(298, 83);
            AlertBalance.Name = "AlertBalance";
            AlertBalance.RowCount = 2;
            AlertBalance.RowStyles.Add(new RowStyle(SizeType.Percent, 75F));
            AlertBalance.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            AlertBalance.Size = new Size(941, 545);
            AlertBalance.TabIndex = 6;
            AlertBalance.Visible = false;
            // 
            // label2
            // 
            label2.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label2.AutoSize = true;
            label2.BackColor = Color.FromArgb(255, 128, 0);
            label2.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            label2.ForeColor = Color.FromArgb(128, 64, 64);
            label2.Location = new Point(3, 0);
            label2.Name = "label2";
            label2.Size = new Size(935, 408);
            label2.TabIndex = 0;
            label2.Text = "Sorry For the Inconvinence!!!\r\n\r\nMachine is having low funds...\r\nPlease do less amount of Transaction...";
            label2.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // Return3_B
            // 
            Return3_B.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            Return3_B.BackColor = Color.FromArgb(255, 128, 0);
            Return3_B.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            Return3_B.ForeColor = Color.FromArgb(128, 64, 64);
            Return3_B.Location = new Point(3, 411);
            Return3_B.Name = "Return3_B";
            Return3_B.Size = new Size(935, 131);
            Return3_B.TabIndex = 1;
            Return3_B.Text = "Return to Main menu";
            Return3_B.UseVisualStyleBackColor = false;
            Return3_B.Click += Return3_B_Click;
            // 
            // CollectAlert
            // 
            CollectAlert.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            CollectAlert.ColumnCount = 1;
            CollectAlert.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            CollectAlert.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 20F));
            CollectAlert.Controls.Add(Continue4_B, 0, 1);
            CollectAlert.Controls.Add(label3, 0, 0);
            CollectAlert.Location = new Point(298, 48);
            CollectAlert.Name = "CollectAlert";
            CollectAlert.RowCount = 2;
            CollectAlert.RowStyles.Add(new RowStyle(SizeType.Percent, 75F));
            CollectAlert.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            CollectAlert.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            CollectAlert.Size = new Size(1017, 592);
            CollectAlert.TabIndex = 7;
            CollectAlert.Visible = false;
            // 
            // Continue4_B
            // 
            Continue4_B.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            Continue4_B.BackColor = Color.FromArgb(255, 128, 0);
            Continue4_B.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            Continue4_B.ForeColor = Color.FromArgb(128, 64, 64);
            Continue4_B.Location = new Point(3, 447);
            Continue4_B.Name = "Continue4_B";
            Continue4_B.Size = new Size(1011, 142);
            Continue4_B.TabIndex = 0;
            Continue4_B.Text = "Continue";
            Continue4_B.UseVisualStyleBackColor = false;
            // 
            // label3
            // 
            label3.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label3.AutoSize = true;
            label3.BackColor = Color.FromArgb(255, 128, 0);
            label3.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            label3.ForeColor = Color.FromArgb(128, 64, 64);
            label3.Location = new Point(3, 0);
            label3.Name = "label3";
            label3.Size = new Size(1011, 444);
            label3.TabIndex = 1;
            label3.Text = "Please Collect Your Cash..";
            label3.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // TransferPage
            // 
            TransferPage.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            TransferPage.ColumnCount = 1;
            TransferPage.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            TransferPage.Controls.Add(Return4_B, 0, 2);
            TransferPage.Controls.Add(label4, 0, 0);
            TransferPage.Controls.Add(listBox1, 0, 1);
            TransferPage.Location = new Point(12, 16);
            TransferPage.Name = "TransferPage";
            TransferPage.RowCount = 3;
            TransferPage.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            TransferPage.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            TransferPage.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            TransferPage.Size = new Size(1531, 661);
            TransferPage.TabIndex = 8;
            TransferPage.Visible = false;
            // 
            // Return4_B
            // 
            Return4_B.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            Return4_B.BackColor = Color.FromArgb(255, 128, 0);
            Return4_B.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            Return4_B.ForeColor = Color.FromArgb(128, 64, 64);
            Return4_B.Location = new Point(3, 498);
            Return4_B.Name = "Return4_B";
            Return4_B.Size = new Size(1525, 160);
            Return4_B.TabIndex = 2;
            Return4_B.Text = "Return To Main Menu";
            Return4_B.UseVisualStyleBackColor = false;
            Return4_B.Click += Return4_B_Click;
            // 
            // label4
            // 
            label4.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label4.AutoSize = true;
            label4.BackColor = Color.FromArgb(255, 128, 0);
            label4.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            label4.ForeColor = Color.FromArgb(128, 64, 64);
            label4.Location = new Point(3, 0);
            label4.Name = "label4";
            label4.Size = new Size(1525, 165);
            label4.TabIndex = 0;
            label4.Text = "Select a Source Account to Transfer Money:";
            label4.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // listBox1
            // 
            listBox1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            listBox1.BackColor = Color.FromArgb(255, 128, 0);
            listBox1.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            listBox1.ForeColor = Color.FromArgb(128, 64, 64);
            listBox1.FormattingEnabled = true;
            listBox1.ItemHeight = 37;
            listBox1.Location = new Point(3, 168);
            listBox1.Name = "listBox1";
            listBox1.Size = new Size(1525, 300);
            listBox1.TabIndex = 1;
            listBox1.SelectedIndexChanged += listBox1_SelectedIndexChanged;
            // 
            // DepositPage
            // 
            DepositPage.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            DepositPage.ColumnCount = 1;
            DepositPage.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            DepositPage.Controls.Add(listBox2, 0, 1);
            DepositPage.Controls.Add(Return5_B, 0, 2);
            DepositPage.Controls.Add(label5, 0, 0);
            DepositPage.Location = new Point(12, 12);
            DepositPage.Name = "DepositPage";
            DepositPage.RowCount = 3;
            DepositPage.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            DepositPage.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            DepositPage.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            DepositPage.Size = new Size(1531, 668);
            DepositPage.TabIndex = 9;
            DepositPage.Visible = false;
            // 
            // listBox2
            // 
            listBox2.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            listBox2.BackColor = Color.FromArgb(255, 128, 0);
            listBox2.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            listBox2.ForeColor = Color.FromArgb(128, 64, 64);
            listBox2.FormattingEnabled = true;
            listBox2.ItemHeight = 37;
            listBox2.Location = new Point(3, 170);
            listBox2.Name = "listBox2";
            listBox2.Size = new Size(1525, 300);
            listBox2.TabIndex = 1;
            listBox2.SelectedIndexChanged += listBox2_SelectedIndexChanged;
            // 
            // Return5_B
            // 
            Return5_B.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            Return5_B.BackColor = Color.FromArgb(255, 128, 0);
            Return5_B.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            Return5_B.ForeColor = Color.FromArgb(128, 64, 64);
            Return5_B.Location = new Point(3, 504);
            Return5_B.Name = "Return5_B";
            Return5_B.Size = new Size(1525, 161);
            Return5_B.TabIndex = 2;
            Return5_B.Text = "Return To Main Menu";
            Return5_B.UseVisualStyleBackColor = false;
            Return5_B.Click += Return5_B_Click;
            // 
            // label5
            // 
            label5.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label5.AutoSize = true;
            label5.BackColor = Color.FromArgb(255, 128, 0);
            label5.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            label5.ForeColor = Color.FromArgb(128, 64, 64);
            label5.Location = new Point(3, 0);
            label5.Name = "label5";
            label5.Size = new Size(1525, 167);
            label5.TabIndex = 0;
            label5.Text = "Select an Account to Deposit Money:";
            label5.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // CheckPage
            // 
            CheckPage.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            CheckPage.ColumnCount = 1;
            CheckPage.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            CheckPage.Controls.Add(listBox3, 0, 1);
            CheckPage.Controls.Add(Return6_B, 0, 2);
            CheckPage.Controls.Add(label6, 0, 0);
            CheckPage.Location = new Point(12, 12);
            CheckPage.Name = "CheckPage";
            CheckPage.RowCount = 3;
            CheckPage.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            CheckPage.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            CheckPage.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            CheckPage.Size = new Size(1531, 668);
            CheckPage.TabIndex = 10;
            CheckPage.Visible = false;
            // 
            // listBox3
            // 
            listBox3.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            listBox3.BackColor = Color.FromArgb(255, 128, 0);
            listBox3.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            listBox3.ForeColor = Color.FromArgb(128, 64, 64);
            listBox3.FormattingEnabled = true;
            listBox3.ItemHeight = 37;
            listBox3.Location = new Point(3, 170);
            listBox3.Name = "listBox3";
            listBox3.Size = new Size(1525, 300);
            listBox3.TabIndex = 1;
            listBox3.SelectedIndexChanged += listBox3_SelectedIndexChanged;
            // 
            // Return6_B
            // 
            Return6_B.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            Return6_B.BackColor = Color.FromArgb(255, 128, 0);
            Return6_B.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            Return6_B.ForeColor = Color.FromArgb(128, 64, 64);
            Return6_B.Location = new Point(3, 504);
            Return6_B.Name = "Return6_B";
            Return6_B.Size = new Size(1525, 161);
            Return6_B.TabIndex = 2;
            Return6_B.Text = "Return To Main Menu";
            Return6_B.UseVisualStyleBackColor = false;
            Return6_B.Click += Return6_B_Click;
            // 
            // label6
            // 
            label6.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label6.AutoSize = true;
            label6.BackColor = Color.FromArgb(255, 128, 0);
            label6.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            label6.ForeColor = Color.FromArgb(128, 64, 64);
            label6.Location = new Point(3, 0);
            label6.Name = "label6";
            label6.Size = new Size(1525, 167);
            label6.TabIndex = 0;
            label6.Text = "Select an Account to Check Balance:";
            label6.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            tableLayoutPanel1.ColumnCount = 1;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 20F));
            tableLayoutPanel1.Controls.Add(button1, 0, 1);
            tableLayoutPanel1.Location = new Point(0, 0);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 2;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel1.Size = new Size(200, 100);
            tableLayoutPanel1.TabIndex = 0;
            // 
            // button1
            // 
            button1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            button1.Location = new Point(3, 23);
            button1.Name = "button1";
            button1.Size = new Size(194, 74);
            button1.TabIndex = 0;
            button1.Text = "Continue";
            button1.UseVisualStyleBackColor = true;
            // 
            // label7
            // 
            label7.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label7.AutoSize = true;
            label7.Location = new Point(3, 0);
            label7.Name = "label7";
            label7.Size = new Size(194, 20);
            label7.TabIndex = 1;
            label7.Text = "Please Collect Your Cash..";
            label7.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel2
            // 
            tableLayoutPanel2.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            tableLayoutPanel2.ColumnCount = 1;
            tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 20F));
            tableLayoutPanel2.Controls.Add(button10, 0, 1);
            tableLayoutPanel2.Location = new Point(0, 0);
            tableLayoutPanel2.Name = "tableLayoutPanel2";
            tableLayoutPanel2.RowCount = 2;
            tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel2.Size = new Size(200, 100);
            tableLayoutPanel2.TabIndex = 0;
            // 
            // button10
            // 
            button10.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            button10.Location = new Point(3, 23);
            button10.Name = "button10";
            button10.Size = new Size(194, 74);
            button10.TabIndex = 0;
            button10.Text = "Continue";
            button10.UseVisualStyleBackColor = true;
            // 
            // label8
            // 
            label8.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label8.AutoSize = true;
            label8.Location = new Point(3, 0);
            label8.Name = "label8";
            label8.Size = new Size(194, 20);
            label8.TabIndex = 1;
            label8.Text = "Please Collect Your Cash..";
            label8.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // BalanceAlert
            // 
            BalanceAlert.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            BalanceAlert.ColumnCount = 1;
            BalanceAlert.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            BalanceAlert.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 20F));
            BalanceAlert.Controls.Add(Return7_B, 0, 1);
            BalanceAlert.Controls.Add(label9, 0, 0);
            BalanceAlert.Location = new Point(298, 48);
            BalanceAlert.Name = "BalanceAlert";
            BalanceAlert.RowCount = 2;
            BalanceAlert.RowStyles.Add(new RowStyle(SizeType.Percent, 75F));
            BalanceAlert.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            BalanceAlert.Size = new Size(1017, 592);
            BalanceAlert.TabIndex = 12;
            BalanceAlert.Visible = false;
            // 
            // Return7_B
            // 
            Return7_B.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            Return7_B.BackColor = Color.FromArgb(255, 128, 0);
            Return7_B.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            Return7_B.ForeColor = Color.FromArgb(128, 64, 64);
            Return7_B.Location = new Point(3, 447);
            Return7_B.Name = "Return7_B";
            Return7_B.Size = new Size(1011, 142);
            Return7_B.TabIndex = 0;
            Return7_B.Text = "Return to Main menu";
            Return7_B.UseVisualStyleBackColor = false;
            Return7_B.Click += Return7_B_Click;
            // 
            // label9
            // 
            label9.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label9.AutoSize = true;
            label9.BackColor = Color.FromArgb(255, 128, 0);
            label9.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            label9.ForeColor = Color.FromArgb(128, 64, 64);
            label9.Location = new Point(3, 0);
            label9.Name = "label9";
            label9.Size = new Size(1011, 444);
            label9.TabIndex = 1;
            label9.Text = "Total Balance:\r\n";
            label9.TextAlign = ContentAlignment.MiddleCenter;
            label9.Click += label9_Click;
            // 
            // LoginAlert
            // 
            LoginAlert.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            LoginAlert.ColumnCount = 1;
            LoginAlert.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            LoginAlert.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 20F));
            LoginAlert.Controls.Add(Continue5_B, 0, 1);
            LoginAlert.Controls.Add(label10, 0, 0);
            LoginAlert.Location = new Point(298, 48);
            LoginAlert.Name = "LoginAlert";
            LoginAlert.RowCount = 2;
            LoginAlert.RowStyles.Add(new RowStyle(SizeType.Percent, 75F));
            LoginAlert.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            LoginAlert.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            LoginAlert.Size = new Size(1017, 595);
            LoginAlert.TabIndex = 13;
            LoginAlert.Visible = false;
            // 
            // Continue5_B
            // 
            Continue5_B.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            Continue5_B.BackColor = Color.FromArgb(255, 128, 0);
            Continue5_B.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            Continue5_B.ForeColor = Color.FromArgb(128, 64, 64);
            Continue5_B.Location = new Point(3, 449);
            Continue5_B.Name = "Continue5_B";
            Continue5_B.Size = new Size(1011, 143);
            Continue5_B.TabIndex = 0;
            Continue5_B.Text = "Continue";
            Continue5_B.UseVisualStyleBackColor = false;
            Continue5_B.Click += Continue5_B_Click;
            // 
            // label10
            // 
            label10.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label10.AutoSize = true;
            label10.BackColor = Color.FromArgb(255, 128, 0);
            label10.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            label10.ForeColor = Color.FromArgb(128, 64, 64);
            label10.Location = new Point(3, 0);
            label10.Name = "label10";
            label10.Size = new Size(1011, 446);
            label10.TabIndex = 1;
            label10.Text = "Alert\r\n\r\nPlease Check your CustomerID or PIN";
            label10.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // LogoutConformation
            // 
            LogoutConformation.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            LogoutConformation.ColumnCount = 2;
            LogoutConformation.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            LogoutConformation.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            LogoutConformation.Controls.Add(Cancel_B, 0, 0);
            LogoutConformation.Controls.Add(Exit_B, 1, 0);
            LogoutConformation.Location = new Point(552, 237);
            LogoutConformation.Name = "LogoutConformation";
            LogoutConformation.RowCount = 1;
            LogoutConformation.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            LogoutConformation.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            LogoutConformation.Size = new Size(445, 108);
            LogoutConformation.TabIndex = 14;
            LogoutConformation.Visible = false;
            // 
            // Cancel_B
            // 
            Cancel_B.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            Cancel_B.BackColor = Color.FromArgb(255, 128, 0);
            Cancel_B.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            Cancel_B.ForeColor = Color.FromArgb(128, 64, 64);
            Cancel_B.Location = new Point(3, 3);
            Cancel_B.Name = "Cancel_B";
            Cancel_B.Size = new Size(216, 102);
            Cancel_B.TabIndex = 0;
            Cancel_B.Text = "Cancel";
            Cancel_B.UseVisualStyleBackColor = false;
            Cancel_B.Click += Cancel_B_Click;
            // 
            // Exit_B
            // 
            Exit_B.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            Exit_B.BackColor = Color.FromArgb(255, 128, 0);
            Exit_B.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            Exit_B.ForeColor = Color.FromArgb(128, 64, 64);
            Exit_B.Location = new Point(225, 3);
            Exit_B.Name = "Exit_B";
            Exit_B.Size = new Size(217, 102);
            Exit_B.TabIndex = 1;
            Exit_B.Text = "Exit";
            Exit_B.UseVisualStyleBackColor = false;
            Exit_B.Click += Exit_B_Click;
            // 
            // tableLayoutPanel3
            // 
            tableLayoutPanel3.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            tableLayoutPanel3.ColumnCount = 1;
            tableLayoutPanel3.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel3.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 20F));
            tableLayoutPanel3.Controls.Add(tableLayoutPanel4, 0, 2);
            tableLayoutPanel3.Controls.Add(button14, 0, 3);
            tableLayoutPanel3.Controls.Add(tableLayoutPanel6, 0, 1);
            tableLayoutPanel3.Location = new Point(0, 0);
            tableLayoutPanel3.Name = "tableLayoutPanel3";
            tableLayoutPanel3.RowCount = 4;
            tableLayoutPanel3.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel3.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel3.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel3.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel3.Size = new Size(200, 100);
            tableLayoutPanel3.TabIndex = 0;
            // 
            // tableLayoutPanel4
            // 
            tableLayoutPanel4.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            tableLayoutPanel4.BackColor = Color.White;
            tableLayoutPanel4.ColumnCount = 2;
            tableLayoutPanel4.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel4.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel4.Controls.Add(button11, 1, 0);
            tableLayoutPanel4.Controls.Add(tableLayoutPanel5, 0, 0);
            tableLayoutPanel4.ForeColor = Color.Black;
            tableLayoutPanel4.Location = new Point(3, 43);
            tableLayoutPanel4.Name = "tableLayoutPanel4";
            tableLayoutPanel4.RowCount = 1;
            tableLayoutPanel4.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tableLayoutPanel4.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel4.Size = new Size(194, 14);
            tableLayoutPanel4.TabIndex = 2;
            // 
            // button11
            // 
            button11.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            button11.BackColor = Color.FromArgb(255, 128, 0);
            button11.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            button11.ForeColor = Color.FromArgb(128, 64, 64);
            button11.Location = new Point(100, 3);
            button11.Name = "button11";
            button11.Size = new Size(91, 8);
            button11.TabIndex = 1;
            button11.Text = "Continue";
            button11.UseVisualStyleBackColor = false;
            // 
            // tableLayoutPanel5
            // 
            tableLayoutPanel5.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            tableLayoutPanel5.BackColor = Color.White;
            tableLayoutPanel5.ColumnCount = 2;
            tableLayoutPanel5.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel5.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel5.Controls.Add(button12, 0, 0);
            tableLayoutPanel5.Controls.Add(button13, 1, 0);
            tableLayoutPanel5.ForeColor = Color.Black;
            tableLayoutPanel5.Location = new Point(3, 3);
            tableLayoutPanel5.Name = "tableLayoutPanel5";
            tableLayoutPanel5.RowCount = 1;
            tableLayoutPanel5.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tableLayoutPanel5.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel5.Size = new Size(91, 8);
            tableLayoutPanel5.TabIndex = 2;
            // 
            // button12
            // 
            button12.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            button12.BackColor = Color.FromArgb(255, 128, 0);
            button12.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            button12.ForeColor = Color.FromArgb(128, 64, 64);
            button12.Location = new Point(3, 3);
            button12.Name = "button12";
            button12.Size = new Size(39, 2);
            button12.TabIndex = 0;
            button12.Text = "Backspace";
            button12.UseVisualStyleBackColor = false;
            // 
            // button13
            // 
            button13.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            button13.BackColor = Color.FromArgb(255, 128, 0);
            button13.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            button13.ForeColor = Color.FromArgb(128, 64, 64);
            button13.Location = new Point(48, 3);
            button13.Name = "button13";
            button13.Size = new Size(40, 2);
            button13.TabIndex = 1;
            button13.Text = "Clear All";
            button13.UseVisualStyleBackColor = false;
            // 
            // button14
            // 
            button14.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            button14.BackColor = Color.FromArgb(255, 128, 0);
            button14.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            button14.ForeColor = Color.FromArgb(128, 64, 64);
            button14.Location = new Point(3, 63);
            button14.Name = "button14";
            button14.Size = new Size(194, 34);
            button14.TabIndex = 3;
            button14.Text = "Return To Accounts";
            button14.UseVisualStyleBackColor = false;
            // 
            // tableLayoutPanel6
            // 
            tableLayoutPanel6.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            tableLayoutPanel6.BackColor = Color.White;
            tableLayoutPanel6.ColumnCount = 2;
            tableLayoutPanel6.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel6.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel6.Controls.Add(tableLayoutPanel7, 0, 0);
            tableLayoutPanel6.Controls.Add(tableLayoutPanel8, 1, 0);
            tableLayoutPanel6.ForeColor = Color.Black;
            tableLayoutPanel6.Location = new Point(3, 23);
            tableLayoutPanel6.Name = "tableLayoutPanel6";
            tableLayoutPanel6.RowCount = 1;
            tableLayoutPanel6.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tableLayoutPanel6.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel6.Size = new Size(194, 14);
            tableLayoutPanel6.TabIndex = 0;
            // 
            // tableLayoutPanel7
            // 
            tableLayoutPanel7.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            tableLayoutPanel7.BackColor = Color.White;
            tableLayoutPanel7.ColumnCount = 5;
            tableLayoutPanel7.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20F));
            tableLayoutPanel7.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20F));
            tableLayoutPanel7.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20F));
            tableLayoutPanel7.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20F));
            tableLayoutPanel7.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20F));
            tableLayoutPanel7.Controls.Add(button15, 4, 0);
            tableLayoutPanel7.Controls.Add(button16, 3, 0);
            tableLayoutPanel7.Controls.Add(button17, 2, 0);
            tableLayoutPanel7.Controls.Add(button18, 1, 0);
            tableLayoutPanel7.Controls.Add(button19, 0, 0);
            tableLayoutPanel7.ForeColor = Color.Black;
            tableLayoutPanel7.Location = new Point(3, 3);
            tableLayoutPanel7.Name = "tableLayoutPanel7";
            tableLayoutPanel7.RowCount = 1;
            tableLayoutPanel7.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tableLayoutPanel7.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel7.Size = new Size(91, 8);
            tableLayoutPanel7.TabIndex = 1;
            // 
            // button15
            // 
            button15.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            button15.BackColor = Color.FromArgb(255, 128, 0);
            button15.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            button15.ForeColor = Color.FromArgb(128, 64, 64);
            button15.Location = new Point(75, 3);
            button15.Name = "button15";
            button15.Size = new Size(13, 2);
            button15.TabIndex = 0;
            button15.Text = "5";
            button15.UseVisualStyleBackColor = false;
            // 
            // button16
            // 
            button16.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            button16.BackColor = Color.FromArgb(255, 128, 0);
            button16.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            button16.ForeColor = Color.FromArgb(128, 64, 64);
            button16.Location = new Point(57, 3);
            button16.Name = "button16";
            button16.Size = new Size(12, 2);
            button16.TabIndex = 1;
            button16.Text = "4";
            button16.UseVisualStyleBackColor = false;
            // 
            // button17
            // 
            button17.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            button17.BackColor = Color.FromArgb(255, 128, 0);
            button17.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            button17.ForeColor = Color.FromArgb(128, 64, 64);
            button17.Location = new Point(39, 3);
            button17.Name = "button17";
            button17.Size = new Size(12, 2);
            button17.TabIndex = 2;
            button17.Text = "3";
            button17.UseVisualStyleBackColor = false;
            // 
            // button18
            // 
            button18.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            button18.BackColor = Color.FromArgb(255, 128, 0);
            button18.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            button18.ForeColor = Color.FromArgb(128, 64, 64);
            button18.Location = new Point(21, 3);
            button18.Name = "button18";
            button18.Size = new Size(12, 2);
            button18.TabIndex = 3;
            button18.Text = "2";
            button18.UseVisualStyleBackColor = false;
            // 
            // button19
            // 
            button19.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            button19.BackColor = Color.FromArgb(255, 128, 0);
            button19.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            button19.ForeColor = Color.FromArgb(128, 64, 64);
            button19.Location = new Point(3, 3);
            button19.Name = "button19";
            button19.Size = new Size(12, 2);
            button19.TabIndex = 4;
            button19.Text = "1";
            button19.UseVisualStyleBackColor = false;
            // 
            // tableLayoutPanel8
            // 
            tableLayoutPanel8.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            tableLayoutPanel8.BackColor = Color.White;
            tableLayoutPanel8.ColumnCount = 5;
            tableLayoutPanel8.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20F));
            tableLayoutPanel8.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20F));
            tableLayoutPanel8.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20F));
            tableLayoutPanel8.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20F));
            tableLayoutPanel8.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20F));
            tableLayoutPanel8.Controls.Add(button20, 4, 0);
            tableLayoutPanel8.Controls.Add(button21, 3, 0);
            tableLayoutPanel8.Controls.Add(button22, 2, 0);
            tableLayoutPanel8.Controls.Add(button23, 1, 0);
            tableLayoutPanel8.Controls.Add(button24, 0, 0);
            tableLayoutPanel8.ForeColor = Color.Black;
            tableLayoutPanel8.Location = new Point(100, 3);
            tableLayoutPanel8.Name = "tableLayoutPanel8";
            tableLayoutPanel8.RowCount = 1;
            tableLayoutPanel8.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tableLayoutPanel8.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel8.Size = new Size(91, 8);
            tableLayoutPanel8.TabIndex = 0;
            // 
            // button20
            // 
            button20.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            button20.BackColor = Color.FromArgb(255, 128, 0);
            button20.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            button20.ForeColor = Color.FromArgb(128, 64, 64);
            button20.Location = new Point(75, 3);
            button20.Name = "button20";
            button20.Size = new Size(13, 2);
            button20.TabIndex = 0;
            button20.Text = "0";
            button20.UseVisualStyleBackColor = false;
            // 
            // button21
            // 
            button21.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            button21.BackColor = Color.FromArgb(255, 128, 0);
            button21.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            button21.ForeColor = Color.FromArgb(128, 64, 64);
            button21.Location = new Point(57, 3);
            button21.Name = "button21";
            button21.Size = new Size(12, 2);
            button21.TabIndex = 1;
            button21.Text = "9";
            button21.UseVisualStyleBackColor = false;
            // 
            // button22
            // 
            button22.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            button22.BackColor = Color.FromArgb(255, 128, 0);
            button22.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            button22.ForeColor = Color.FromArgb(128, 64, 64);
            button22.Location = new Point(39, 3);
            button22.Name = "button22";
            button22.Size = new Size(12, 2);
            button22.TabIndex = 2;
            button22.Text = "8";
            button22.UseVisualStyleBackColor = false;
            // 
            // button23
            // 
            button23.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            button23.BackColor = Color.FromArgb(255, 128, 0);
            button23.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            button23.ForeColor = Color.FromArgb(128, 64, 64);
            button23.Location = new Point(21, 3);
            button23.Name = "button23";
            button23.Size = new Size(12, 2);
            button23.TabIndex = 3;
            button23.Text = "7";
            button23.UseVisualStyleBackColor = false;
            // 
            // button24
            // 
            button24.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            button24.BackColor = Color.FromArgb(255, 128, 0);
            button24.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            button24.ForeColor = Color.FromArgb(128, 64, 64);
            button24.Location = new Point(3, 3);
            button24.Name = "button24";
            button24.Size = new Size(12, 2);
            button24.TabIndex = 4;
            button24.Text = "6";
            button24.UseVisualStyleBackColor = false;
            // 
            // tableLayoutPanel9
            // 
            tableLayoutPanel9.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            tableLayoutPanel9.BackColor = Color.FromArgb(255, 128, 0);
            tableLayoutPanel9.ColumnCount = 2;
            tableLayoutPanel9.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel9.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel9.Controls.Add(label11, 0, 0);
            tableLayoutPanel9.ForeColor = Color.FromArgb(128, 64, 64);
            tableLayoutPanel9.Location = new Point(0, 0);
            tableLayoutPanel9.Name = "tableLayoutPanel9";
            tableLayoutPanel9.RowCount = 1;
            tableLayoutPanel9.Size = new Size(200, 100);
            tableLayoutPanel9.TabIndex = 0;
            // 
            // label11
            // 
            label11.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label11.AutoSize = true;
            label11.BackColor = Color.FromArgb(255, 128, 0);
            label11.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            label11.ForeColor = Color.FromArgb(128, 64, 64);
            label11.Location = new Point(3, 0);
            label11.Name = "label11";
            label11.Size = new Size(94, 114);
            label11.TabIndex = 0;
            label11.Text = "Enter Amount:";
            label11.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // textBox1
            // 
            textBox1.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            textBox1.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            textBox1.Location = new Point(103, 35);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(94, 43);
            textBox1.TabIndex = 1;
            // 
            // EnterPageDeposit
            // 
            EnterPageDeposit.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            EnterPageDeposit.ColumnCount = 1;
            EnterPageDeposit.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            EnterPageDeposit.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 20F));
            EnterPageDeposit.Controls.Add(tableLayoutPanel11, 0, 2);
            EnterPageDeposit.Controls.Add(button28, 0, 3);
            EnterPageDeposit.Controls.Add(tableLayoutPanel13, 0, 1);
            EnterPageDeposit.Controls.Add(tableLayoutPanel16, 0, 0);
            EnterPageDeposit.Location = new Point(10, 8);
            EnterPageDeposit.Name = "EnterPageDeposit";
            EnterPageDeposit.RowCount = 4;
            EnterPageDeposit.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            EnterPageDeposit.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            EnterPageDeposit.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            EnterPageDeposit.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            EnterPageDeposit.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            EnterPageDeposit.Size = new Size(1531, 676);
            EnterPageDeposit.TabIndex = 15;
            EnterPageDeposit.Visible = false;
            // 
            // tableLayoutPanel11
            // 
            tableLayoutPanel11.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            tableLayoutPanel11.BackColor = Color.White;
            tableLayoutPanel11.ColumnCount = 2;
            tableLayoutPanel11.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel11.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel11.Controls.Add(button25, 1, 0);
            tableLayoutPanel11.Controls.Add(tableLayoutPanel12, 0, 0);
            tableLayoutPanel11.ForeColor = Color.Black;
            tableLayoutPanel11.Location = new Point(3, 341);
            tableLayoutPanel11.Name = "tableLayoutPanel11";
            tableLayoutPanel11.RowCount = 1;
            tableLayoutPanel11.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tableLayoutPanel11.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel11.Size = new Size(1525, 163);
            tableLayoutPanel11.TabIndex = 2;
            // 
            // button25
            // 
            button25.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            button25.BackColor = Color.FromArgb(255, 128, 0);
            button25.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            button25.ForeColor = Color.FromArgb(128, 64, 64);
            button25.Location = new Point(765, 3);
            button25.Name = "button25";
            button25.Size = new Size(757, 157);
            button25.TabIndex = 1;
            button25.Text = "Continue";
            button25.UseVisualStyleBackColor = false;
            button25.Click += button25_Click;
            // 
            // tableLayoutPanel12
            // 
            tableLayoutPanel12.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            tableLayoutPanel12.BackColor = Color.White;
            tableLayoutPanel12.ColumnCount = 2;
            tableLayoutPanel12.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel12.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel12.Controls.Add(button26, 0, 0);
            tableLayoutPanel12.Controls.Add(button27, 1, 0);
            tableLayoutPanel12.ForeColor = Color.Black;
            tableLayoutPanel12.Location = new Point(3, 3);
            tableLayoutPanel12.Name = "tableLayoutPanel12";
            tableLayoutPanel12.RowCount = 1;
            tableLayoutPanel12.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tableLayoutPanel12.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel12.Size = new Size(756, 157);
            tableLayoutPanel12.TabIndex = 2;
            // 
            // button26
            // 
            button26.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            button26.BackColor = Color.FromArgb(255, 128, 0);
            button26.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            button26.ForeColor = Color.FromArgb(128, 64, 64);
            button26.Location = new Point(3, 3);
            button26.Name = "button26";
            button26.Size = new Size(372, 151);
            button26.TabIndex = 0;
            button26.Text = "Backspace";
            button26.UseVisualStyleBackColor = false;
            button26.Click += button26_Click;
            // 
            // button27
            // 
            button27.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            button27.BackColor = Color.FromArgb(255, 128, 0);
            button27.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            button27.ForeColor = Color.FromArgb(128, 64, 64);
            button27.Location = new Point(381, 3);
            button27.Name = "button27";
            button27.Size = new Size(372, 151);
            button27.TabIndex = 1;
            button27.Text = "Clear All";
            button27.UseVisualStyleBackColor = false;
            button27.Click += button27_Click;
            // 
            // button28
            // 
            button28.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            button28.BackColor = Color.FromArgb(255, 128, 0);
            button28.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            button28.ForeColor = Color.FromArgb(128, 64, 64);
            button28.Location = new Point(3, 510);
            button28.Name = "button28";
            button28.Size = new Size(1525, 163);
            button28.TabIndex = 3;
            button28.Text = "Return To Accounts";
            button28.UseVisualStyleBackColor = false;
            button28.Click += button28_Click;
            // 
            // tableLayoutPanel13
            // 
            tableLayoutPanel13.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            tableLayoutPanel13.BackColor = Color.White;
            tableLayoutPanel13.ColumnCount = 2;
            tableLayoutPanel13.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel13.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel13.Controls.Add(tableLayoutPanel14, 0, 0);
            tableLayoutPanel13.Controls.Add(tableLayoutPanel15, 1, 0);
            tableLayoutPanel13.ForeColor = Color.Black;
            tableLayoutPanel13.Location = new Point(3, 172);
            tableLayoutPanel13.Name = "tableLayoutPanel13";
            tableLayoutPanel13.RowCount = 1;
            tableLayoutPanel13.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tableLayoutPanel13.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel13.Size = new Size(1525, 163);
            tableLayoutPanel13.TabIndex = 0;
            // 
            // tableLayoutPanel14
            // 
            tableLayoutPanel14.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            tableLayoutPanel14.BackColor = Color.White;
            tableLayoutPanel14.ColumnCount = 5;
            tableLayoutPanel14.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20F));
            tableLayoutPanel14.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20F));
            tableLayoutPanel14.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20F));
            tableLayoutPanel14.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20F));
            tableLayoutPanel14.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20F));
            tableLayoutPanel14.Controls.Add(button29, 4, 0);
            tableLayoutPanel14.Controls.Add(button30, 3, 0);
            tableLayoutPanel14.Controls.Add(button31, 2, 0);
            tableLayoutPanel14.Controls.Add(button32, 1, 0);
            tableLayoutPanel14.Controls.Add(button33, 0, 0);
            tableLayoutPanel14.ForeColor = Color.Black;
            tableLayoutPanel14.Location = new Point(3, 3);
            tableLayoutPanel14.Name = "tableLayoutPanel14";
            tableLayoutPanel14.RowCount = 1;
            tableLayoutPanel14.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tableLayoutPanel14.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel14.Size = new Size(756, 157);
            tableLayoutPanel14.TabIndex = 1;
            // 
            // button29
            // 
            button29.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            button29.BackColor = Color.FromArgb(255, 128, 0);
            button29.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            button29.ForeColor = Color.FromArgb(128, 64, 64);
            button29.Location = new Point(607, 3);
            button29.Name = "button29";
            button29.Size = new Size(146, 151);
            button29.TabIndex = 0;
            button29.Text = "5";
            button29.UseVisualStyleBackColor = false;
            button29.Click += button29_Click_1;
            // 
            // button30
            // 
            button30.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            button30.BackColor = Color.FromArgb(255, 128, 0);
            button30.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            button30.ForeColor = Color.FromArgb(128, 64, 64);
            button30.Location = new Point(456, 3);
            button30.Name = "button30";
            button30.Size = new Size(145, 151);
            button30.TabIndex = 1;
            button30.Text = "4";
            button30.UseVisualStyleBackColor = false;
            button30.Click += button30_Click_1;
            // 
            // button31
            // 
            button31.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            button31.BackColor = Color.FromArgb(255, 128, 0);
            button31.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            button31.ForeColor = Color.FromArgb(128, 64, 64);
            button31.Location = new Point(305, 3);
            button31.Name = "button31";
            button31.Size = new Size(145, 151);
            button31.TabIndex = 2;
            button31.Text = "3";
            button31.UseVisualStyleBackColor = false;
            button31.Click += button31_Click_1;
            // 
            // button32
            // 
            button32.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            button32.BackColor = Color.FromArgb(255, 128, 0);
            button32.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            button32.ForeColor = Color.FromArgb(128, 64, 64);
            button32.Location = new Point(154, 3);
            button32.Name = "button32";
            button32.Size = new Size(145, 151);
            button32.TabIndex = 3;
            button32.Text = "2";
            button32.UseVisualStyleBackColor = false;
            button32.Click += button32_Click_1;
            // 
            // button33
            // 
            button33.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            button33.BackColor = Color.FromArgb(255, 128, 0);
            button33.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            button33.ForeColor = Color.FromArgb(128, 64, 64);
            button33.Location = new Point(3, 3);
            button33.Name = "button33";
            button33.Size = new Size(145, 151);
            button33.TabIndex = 4;
            button33.Text = "1";
            button33.UseVisualStyleBackColor = false;
            button33.Click += button33_Click_2;
            // 
            // tableLayoutPanel15
            // 
            tableLayoutPanel15.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            tableLayoutPanel15.BackColor = Color.White;
            tableLayoutPanel15.ColumnCount = 5;
            tableLayoutPanel15.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20F));
            tableLayoutPanel15.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20F));
            tableLayoutPanel15.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20F));
            tableLayoutPanel15.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20F));
            tableLayoutPanel15.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20F));
            tableLayoutPanel15.Controls.Add(button34, 4, 0);
            tableLayoutPanel15.Controls.Add(button35, 3, 0);
            tableLayoutPanel15.Controls.Add(button36, 2, 0);
            tableLayoutPanel15.Controls.Add(button37, 1, 0);
            tableLayoutPanel15.Controls.Add(button38, 0, 0);
            tableLayoutPanel15.ForeColor = Color.Black;
            tableLayoutPanel15.Location = new Point(765, 3);
            tableLayoutPanel15.Name = "tableLayoutPanel15";
            tableLayoutPanel15.RowCount = 1;
            tableLayoutPanel15.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tableLayoutPanel15.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel15.Size = new Size(757, 157);
            tableLayoutPanel15.TabIndex = 0;
            // 
            // button34
            // 
            button34.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            button34.BackColor = Color.FromArgb(255, 128, 0);
            button34.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            button34.ForeColor = Color.FromArgb(128, 64, 64);
            button34.Location = new Point(607, 3);
            button34.Name = "button34";
            button34.Size = new Size(147, 151);
            button34.TabIndex = 0;
            button34.Text = "0";
            button34.UseVisualStyleBackColor = false;
            button34.Click += button34_Click;
            // 
            // button35
            // 
            button35.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            button35.BackColor = Color.FromArgb(255, 128, 0);
            button35.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            button35.ForeColor = Color.FromArgb(128, 64, 64);
            button35.Location = new Point(456, 3);
            button35.Name = "button35";
            button35.Size = new Size(145, 151);
            button35.TabIndex = 1;
            button35.Text = "9";
            button35.UseVisualStyleBackColor = false;
            button35.Click += button35_Click_1;
            // 
            // button36
            // 
            button36.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            button36.BackColor = Color.FromArgb(255, 128, 0);
            button36.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            button36.ForeColor = Color.FromArgb(128, 64, 64);
            button36.Location = new Point(305, 3);
            button36.Name = "button36";
            button36.Size = new Size(145, 151);
            button36.TabIndex = 2;
            button36.Text = "8";
            button36.UseVisualStyleBackColor = false;
            button36.Click += button36_Click_1;
            // 
            // button37
            // 
            button37.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            button37.BackColor = Color.FromArgb(255, 128, 0);
            button37.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            button37.ForeColor = Color.FromArgb(128, 64, 64);
            button37.Location = new Point(154, 3);
            button37.Name = "button37";
            button37.Size = new Size(145, 151);
            button37.TabIndex = 3;
            button37.Text = "7";
            button37.UseVisualStyleBackColor = false;
            button37.Click += button37_Click_1;
            // 
            // button38
            // 
            button38.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            button38.BackColor = Color.FromArgb(255, 128, 0);
            button38.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            button38.ForeColor = Color.FromArgb(128, 64, 64);
            button38.Location = new Point(3, 3);
            button38.Name = "button38";
            button38.Size = new Size(145, 151);
            button38.TabIndex = 4;
            button38.Text = "6";
            button38.UseVisualStyleBackColor = false;
            button38.Click += button38_Click_1;
            // 
            // tableLayoutPanel16
            // 
            tableLayoutPanel16.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            tableLayoutPanel16.BackColor = Color.FromArgb(255, 128, 0);
            tableLayoutPanel16.ColumnCount = 2;
            tableLayoutPanel16.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel16.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel16.Controls.Add(label12, 0, 0);
            tableLayoutPanel16.Controls.Add(textBox2, 1, 0);
            tableLayoutPanel16.ForeColor = Color.FromArgb(128, 64, 64);
            tableLayoutPanel16.Location = new Point(3, 3);
            tableLayoutPanel16.Name = "tableLayoutPanel16";
            tableLayoutPanel16.RowCount = 1;
            tableLayoutPanel16.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tableLayoutPanel16.Size = new Size(1525, 163);
            tableLayoutPanel16.TabIndex = 1;
            // 
            // label12
            // 
            label12.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label12.AutoSize = true;
            label12.BackColor = Color.FromArgb(255, 128, 0);
            label12.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            label12.ForeColor = Color.FromArgb(128, 64, 64);
            label12.Location = new Point(3, 0);
            label12.Name = "label12";
            label12.Size = new Size(756, 163);
            label12.TabIndex = 0;
            label12.Text = "Enter Amount to Deposit:\r\n(max.$3000)";
            label12.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // textBox2
            // 
            textBox2.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            textBox2.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            textBox2.Location = new Point(765, 60);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(757, 43);
            textBox2.TabIndex = 1;
            // 
            // tableLayoutPanel10
            // 
            tableLayoutPanel10.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            tableLayoutPanel10.ColumnCount = 1;
            tableLayoutPanel10.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel10.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 20F));
            tableLayoutPanel10.Controls.Add(button39, 0, 1);
            tableLayoutPanel10.Location = new Point(0, 0);
            tableLayoutPanel10.Name = "tableLayoutPanel10";
            tableLayoutPanel10.RowCount = 2;
            tableLayoutPanel10.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel10.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel10.Size = new Size(200, 100);
            tableLayoutPanel10.TabIndex = 0;
            // 
            // button39
            // 
            button39.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            button39.BackColor = Color.FromArgb(255, 128, 0);
            button39.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            button39.ForeColor = Color.FromArgb(128, 64, 64);
            button39.Location = new Point(3, 23);
            button39.Name = "button39";
            button39.Size = new Size(194, 74);
            button39.TabIndex = 0;
            button39.Text = "Continue";
            button39.UseVisualStyleBackColor = false;
            // 
            // label13
            // 
            label13.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label13.AutoSize = true;
            label13.BackColor = Color.FromArgb(255, 128, 0);
            label13.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            label13.ForeColor = Color.FromArgb(128, 64, 64);
            label13.Location = new Point(3, 0);
            label13.Name = "label13";
            label13.Size = new Size(194, 114);
            label13.TabIndex = 1;
            label13.Text = "Please Collect Your Cash..";
            label13.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // DepositAlert
            // 
            DepositAlert.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            DepositAlert.ColumnCount = 1;
            DepositAlert.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            DepositAlert.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 20F));
            DepositAlert.Controls.Add(Return_Deposit, 0, 1);
            DepositAlert.Controls.Add(label14, 0, 0);
            DepositAlert.Location = new Point(267, 50);
            DepositAlert.Name = "DepositAlert";
            DepositAlert.RowCount = 2;
            DepositAlert.RowStyles.Add(new RowStyle(SizeType.Percent, 75F));
            DepositAlert.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            DepositAlert.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            DepositAlert.Size = new Size(1017, 592);
            DepositAlert.TabIndex = 16;
            DepositAlert.Visible = false;
            // 
            // Return_Deposit
            // 
            Return_Deposit.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            Return_Deposit.BackColor = Color.FromArgb(255, 128, 0);
            Return_Deposit.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            Return_Deposit.ForeColor = Color.FromArgb(128, 64, 64);
            Return_Deposit.Location = new Point(3, 447);
            Return_Deposit.Name = "Return_Deposit";
            Return_Deposit.Size = new Size(1011, 142);
            Return_Deposit.TabIndex = 0;
            Return_Deposit.Text = "Continue";
            Return_Deposit.UseVisualStyleBackColor = false;
            Return_Deposit.Click += Return_Deposit_Click;
            // 
            // label14
            // 
            label14.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label14.AutoSize = true;
            label14.BackColor = Color.FromArgb(255, 128, 0);
            label14.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            label14.ForeColor = Color.FromArgb(128, 64, 64);
            label14.Location = new Point(3, 0);
            label14.Name = "label14";
            label14.Size = new Size(1011, 444);
            label14.TabIndex = 1;
            label14.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // Enter_Page2
            // 
            Enter_Page2.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            Enter_Page2.ColumnCount = 1;
            Enter_Page2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            Enter_Page2.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 20F));
            Enter_Page2.Controls.Add(tableLayoutPanel18, 0, 2);
            Enter_Page2.Controls.Add(button43, 0, 3);
            Enter_Page2.Controls.Add(tableLayoutPanel20, 0, 1);
            Enter_Page2.Controls.Add(tableLayoutPanel23, 0, 0);
            Enter_Page2.Location = new Point(9, 8);
            Enter_Page2.Name = "Enter_Page2";
            Enter_Page2.RowCount = 4;
            Enter_Page2.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            Enter_Page2.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            Enter_Page2.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            Enter_Page2.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            Enter_Page2.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            Enter_Page2.Size = new Size(1531, 676);
            Enter_Page2.TabIndex = 17;
            Enter_Page2.Visible = false;
            // 
            // tableLayoutPanel18
            // 
            tableLayoutPanel18.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            tableLayoutPanel18.BackColor = Color.White;
            tableLayoutPanel18.ColumnCount = 2;
            tableLayoutPanel18.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel18.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel18.Controls.Add(button40, 1, 0);
            tableLayoutPanel18.Controls.Add(tableLayoutPanel19, 0, 0);
            tableLayoutPanel18.ForeColor = Color.Black;
            tableLayoutPanel18.Location = new Point(3, 341);
            tableLayoutPanel18.Name = "tableLayoutPanel18";
            tableLayoutPanel18.RowCount = 1;
            tableLayoutPanel18.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tableLayoutPanel18.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel18.Size = new Size(1525, 163);
            tableLayoutPanel18.TabIndex = 2;
            // 
            // button40
            // 
            button40.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            button40.BackColor = Color.FromArgb(255, 128, 0);
            button40.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            button40.ForeColor = Color.FromArgb(128, 64, 64);
            button40.Location = new Point(765, 3);
            button40.Name = "button40";
            button40.Size = new Size(757, 157);
            button40.TabIndex = 1;
            button40.Text = "Continue";
            button40.UseVisualStyleBackColor = false;
            button40.Click += button40_Click;
            // 
            // tableLayoutPanel19
            // 
            tableLayoutPanel19.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            tableLayoutPanel19.BackColor = Color.White;
            tableLayoutPanel19.ColumnCount = 2;
            tableLayoutPanel19.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel19.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel19.Controls.Add(button41, 0, 0);
            tableLayoutPanel19.Controls.Add(button42, 1, 0);
            tableLayoutPanel19.ForeColor = Color.Black;
            tableLayoutPanel19.Location = new Point(3, 3);
            tableLayoutPanel19.Name = "tableLayoutPanel19";
            tableLayoutPanel19.RowCount = 1;
            tableLayoutPanel19.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tableLayoutPanel19.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel19.Size = new Size(756, 157);
            tableLayoutPanel19.TabIndex = 2;
            // 
            // button41
            // 
            button41.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            button41.BackColor = Color.FromArgb(255, 128, 0);
            button41.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            button41.ForeColor = Color.FromArgb(128, 64, 64);
            button41.Location = new Point(3, 3);
            button41.Name = "button41";
            button41.Size = new Size(372, 151);
            button41.TabIndex = 0;
            button41.Text = "Backspace";
            button41.UseVisualStyleBackColor = false;
            button41.Click += button41_Click;
            // 
            // button42
            // 
            button42.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            button42.BackColor = Color.FromArgb(255, 128, 0);
            button42.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            button42.ForeColor = Color.FromArgb(128, 64, 64);
            button42.Location = new Point(381, 3);
            button42.Name = "button42";
            button42.Size = new Size(372, 151);
            button42.TabIndex = 1;
            button42.Text = "Clear All";
            button42.UseVisualStyleBackColor = false;
            button42.Click += button42_Click;
            // 
            // button43
            // 
            button43.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            button43.BackColor = Color.FromArgb(255, 128, 0);
            button43.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            button43.ForeColor = Color.FromArgb(128, 64, 64);
            button43.Location = new Point(3, 510);
            button43.Name = "button43";
            button43.Size = new Size(1525, 163);
            button43.TabIndex = 3;
            button43.Text = "Return To Accounts";
            button43.UseVisualStyleBackColor = false;
            button43.Click += button43_Click;
            // 
            // tableLayoutPanel20
            // 
            tableLayoutPanel20.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            tableLayoutPanel20.BackColor = Color.White;
            tableLayoutPanel20.ColumnCount = 2;
            tableLayoutPanel20.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel20.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel20.Controls.Add(tableLayoutPanel21, 0, 0);
            tableLayoutPanel20.Controls.Add(tableLayoutPanel22, 1, 0);
            tableLayoutPanel20.ForeColor = Color.Black;
            tableLayoutPanel20.Location = new Point(3, 172);
            tableLayoutPanel20.Name = "tableLayoutPanel20";
            tableLayoutPanel20.RowCount = 1;
            tableLayoutPanel20.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tableLayoutPanel20.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel20.Size = new Size(1525, 163);
            tableLayoutPanel20.TabIndex = 0;
            // 
            // tableLayoutPanel21
            // 
            tableLayoutPanel21.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            tableLayoutPanel21.BackColor = Color.White;
            tableLayoutPanel21.ColumnCount = 5;
            tableLayoutPanel21.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20F));
            tableLayoutPanel21.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20F));
            tableLayoutPanel21.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20F));
            tableLayoutPanel21.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20F));
            tableLayoutPanel21.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20F));
            tableLayoutPanel21.Controls.Add(button44, 4, 0);
            tableLayoutPanel21.Controls.Add(button45, 3, 0);
            tableLayoutPanel21.Controls.Add(button46, 2, 0);
            tableLayoutPanel21.Controls.Add(button47, 1, 0);
            tableLayoutPanel21.Controls.Add(button48, 0, 0);
            tableLayoutPanel21.ForeColor = Color.Black;
            tableLayoutPanel21.Location = new Point(3, 3);
            tableLayoutPanel21.Name = "tableLayoutPanel21";
            tableLayoutPanel21.RowCount = 1;
            tableLayoutPanel21.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tableLayoutPanel21.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel21.Size = new Size(756, 157);
            tableLayoutPanel21.TabIndex = 1;
            // 
            // button44
            // 
            button44.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            button44.BackColor = Color.FromArgb(255, 128, 0);
            button44.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            button44.ForeColor = Color.FromArgb(128, 64, 64);
            button44.Location = new Point(607, 3);
            button44.Name = "button44";
            button44.Size = new Size(146, 151);
            button44.TabIndex = 0;
            button44.Text = "5";
            button44.UseVisualStyleBackColor = false;
            button44.Click += button44_Click;
            // 
            // button45
            // 
            button45.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            button45.BackColor = Color.FromArgb(255, 128, 0);
            button45.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            button45.ForeColor = Color.FromArgb(128, 64, 64);
            button45.Location = new Point(456, 3);
            button45.Name = "button45";
            button45.Size = new Size(145, 151);
            button45.TabIndex = 1;
            button45.Text = "4";
            button45.UseVisualStyleBackColor = false;
            button45.Click += button45_Click;
            // 
            // button46
            // 
            button46.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            button46.BackColor = Color.FromArgb(255, 128, 0);
            button46.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            button46.ForeColor = Color.FromArgb(128, 64, 64);
            button46.Location = new Point(305, 3);
            button46.Name = "button46";
            button46.Size = new Size(145, 151);
            button46.TabIndex = 2;
            button46.Text = "3";
            button46.UseVisualStyleBackColor = false;
            button46.Click += button46_Click;
            // 
            // button47
            // 
            button47.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            button47.BackColor = Color.FromArgb(255, 128, 0);
            button47.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            button47.ForeColor = Color.FromArgb(128, 64, 64);
            button47.Location = new Point(154, 3);
            button47.Name = "button47";
            button47.Size = new Size(145, 151);
            button47.TabIndex = 3;
            button47.Text = "2";
            button47.UseVisualStyleBackColor = false;
            button47.Click += button47_Click;
            // 
            // button48
            // 
            button48.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            button48.BackColor = Color.FromArgb(255, 128, 0);
            button48.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            button48.ForeColor = Color.FromArgb(128, 64, 64);
            button48.Location = new Point(3, 3);
            button48.Name = "button48";
            button48.Size = new Size(145, 151);
            button48.TabIndex = 4;
            button48.Text = "1";
            button48.UseVisualStyleBackColor = false;
            button48.Click += button48_Click;
            // 
            // tableLayoutPanel22
            // 
            tableLayoutPanel22.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            tableLayoutPanel22.BackColor = Color.White;
            tableLayoutPanel22.ColumnCount = 5;
            tableLayoutPanel22.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20F));
            tableLayoutPanel22.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20F));
            tableLayoutPanel22.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20F));
            tableLayoutPanel22.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20F));
            tableLayoutPanel22.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20F));
            tableLayoutPanel22.Controls.Add(button49, 4, 0);
            tableLayoutPanel22.Controls.Add(button50, 3, 0);
            tableLayoutPanel22.Controls.Add(button51, 2, 0);
            tableLayoutPanel22.Controls.Add(button52, 1, 0);
            tableLayoutPanel22.Controls.Add(button53, 0, 0);
            tableLayoutPanel22.ForeColor = Color.Black;
            tableLayoutPanel22.Location = new Point(765, 3);
            tableLayoutPanel22.Name = "tableLayoutPanel22";
            tableLayoutPanel22.RowCount = 1;
            tableLayoutPanel22.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tableLayoutPanel22.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel22.Size = new Size(757, 157);
            tableLayoutPanel22.TabIndex = 0;
            // 
            // button49
            // 
            button49.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            button49.BackColor = Color.FromArgb(255, 128, 0);
            button49.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            button49.ForeColor = Color.FromArgb(128, 64, 64);
            button49.Location = new Point(607, 3);
            button49.Name = "button49";
            button49.Size = new Size(147, 151);
            button49.TabIndex = 0;
            button49.Text = "0";
            button49.UseVisualStyleBackColor = false;
            button49.Click += button49_Click;
            // 
            // button50
            // 
            button50.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            button50.BackColor = Color.FromArgb(255, 128, 0);
            button50.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            button50.ForeColor = Color.FromArgb(128, 64, 64);
            button50.Location = new Point(456, 3);
            button50.Name = "button50";
            button50.Size = new Size(145, 151);
            button50.TabIndex = 1;
            button50.Text = "9";
            button50.UseVisualStyleBackColor = false;
            button50.Click += button50_Click;
            // 
            // button51
            // 
            button51.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            button51.BackColor = Color.FromArgb(255, 128, 0);
            button51.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            button51.ForeColor = Color.FromArgb(128, 64, 64);
            button51.Location = new Point(305, 3);
            button51.Name = "button51";
            button51.Size = new Size(145, 151);
            button51.TabIndex = 2;
            button51.Text = "8";
            button51.UseVisualStyleBackColor = false;
            button51.Click += button51_Click;
            // 
            // button52
            // 
            button52.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            button52.BackColor = Color.FromArgb(255, 128, 0);
            button52.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            button52.ForeColor = Color.FromArgb(128, 64, 64);
            button52.Location = new Point(154, 3);
            button52.Name = "button52";
            button52.Size = new Size(145, 151);
            button52.TabIndex = 3;
            button52.Text = "7";
            button52.UseVisualStyleBackColor = false;
            button52.Click += button52_Click;
            // 
            // button53
            // 
            button53.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            button53.BackColor = Color.FromArgb(255, 128, 0);
            button53.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            button53.ForeColor = Color.FromArgb(128, 64, 64);
            button53.Location = new Point(3, 3);
            button53.Name = "button53";
            button53.Size = new Size(145, 151);
            button53.TabIndex = 4;
            button53.Text = "6";
            button53.UseVisualStyleBackColor = false;
            button53.Click += button53_Click;
            // 
            // tableLayoutPanel23
            // 
            tableLayoutPanel23.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            tableLayoutPanel23.BackColor = Color.FromArgb(255, 128, 0);
            tableLayoutPanel23.ColumnCount = 2;
            tableLayoutPanel23.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel23.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel23.Controls.Add(label15, 0, 0);
            tableLayoutPanel23.Controls.Add(textBox3, 1, 0);
            tableLayoutPanel23.ForeColor = Color.FromArgb(128, 64, 64);
            tableLayoutPanel23.Location = new Point(3, 3);
            tableLayoutPanel23.Name = "tableLayoutPanel23";
            tableLayoutPanel23.RowCount = 1;
            tableLayoutPanel23.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tableLayoutPanel23.Size = new Size(1525, 163);
            tableLayoutPanel23.TabIndex = 1;
            // 
            // label15
            // 
            label15.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label15.AutoSize = true;
            label15.BackColor = Color.FromArgb(255, 128, 0);
            label15.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            label15.ForeColor = Color.FromArgb(128, 64, 64);
            label15.Location = new Point(3, 0);
            label15.Name = "label15";
            label15.Size = new Size(756, 163);
            label15.TabIndex = 0;
            label15.Text = "Enter Amount to Transfer:\r\n(max.$3000)";
            label15.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // textBox3
            // 
            textBox3.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            textBox3.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            textBox3.Location = new Point(765, 60);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(757, 43);
            textBox3.TabIndex = 1;
            // 
            // TransferAlert
            // 
            TransferAlert.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            TransferAlert.ColumnCount = 1;
            TransferAlert.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            TransferAlert.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 20F));
            TransferAlert.Controls.Add(button54, 0, 1);
            TransferAlert.Controls.Add(label16, 0, 0);
            TransferAlert.Location = new Point(275, 58);
            TransferAlert.Name = "TransferAlert";
            TransferAlert.RowCount = 2;
            TransferAlert.RowStyles.Add(new RowStyle(SizeType.Percent, 75F));
            TransferAlert.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            TransferAlert.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            TransferAlert.Size = new Size(1017, 592);
            TransferAlert.TabIndex = 18;
            TransferAlert.Visible = false;
            // 
            // button54
            // 
            button54.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            button54.BackColor = Color.FromArgb(255, 128, 0);
            button54.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            button54.ForeColor = Color.FromArgb(128, 64, 64);
            button54.Location = new Point(3, 447);
            button54.Name = "button54";
            button54.Size = new Size(1011, 142);
            button54.TabIndex = 0;
            button54.Text = "Continue";
            button54.UseVisualStyleBackColor = false;
            button54.Click += button54_Click;
            // 
            // label16
            // 
            label16.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label16.AutoSize = true;
            label16.BackColor = Color.FromArgb(255, 128, 0);
            label16.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            label16.ForeColor = Color.FromArgb(128, 64, 64);
            label16.Location = new Point(3, 0);
            label16.Name = "label16";
            label16.Size = new Size(1011, 444);
            label16.TabIndex = 1;
            label16.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // TransferPage2
            // 
            TransferPage2.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            TransferPage2.ColumnCount = 1;
            TransferPage2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            TransferPage2.Controls.Add(button55, 0, 2);
            TransferPage2.Controls.Add(label17, 0, 0);
            TransferPage2.Controls.Add(listBox4, 0, 1);
            TransferPage2.Location = new Point(10, 16);
            TransferPage2.Name = "TransferPage2";
            TransferPage2.RowCount = 3;
            TransferPage2.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            TransferPage2.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            TransferPage2.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            TransferPage2.Size = new Size(1531, 661);
            TransferPage2.TabIndex = 19;
            TransferPage2.Visible = false;
            // 
            // button55
            // 
            button55.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            button55.BackColor = Color.FromArgb(255, 128, 0);
            button55.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            button55.ForeColor = Color.FromArgb(128, 64, 64);
            button55.Location = new Point(3, 498);
            button55.Name = "button55";
            button55.Size = new Size(1525, 160);
            button55.TabIndex = 2;
            button55.Text = "Return To Source Account Selection";
            button55.UseVisualStyleBackColor = false;
            button55.Click += button55_Click;
            // 
            // label17
            // 
            label17.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label17.AutoSize = true;
            label17.BackColor = Color.FromArgb(255, 128, 0);
            label17.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            label17.ForeColor = Color.FromArgb(128, 64, 64);
            label17.Location = new Point(3, 0);
            label17.Name = "label17";
            label17.Size = new Size(1525, 165);
            label17.TabIndex = 0;
            label17.Text = "Select an Destination Account to Transfer Money:";
            label17.TextAlign = ContentAlignment.MiddleCenter;
            label17.Click += label17_Click;
            // 
            // listBox4
            // 
            listBox4.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            listBox4.BackColor = Color.FromArgb(255, 128, 0);
            listBox4.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic);
            listBox4.ForeColor = Color.FromArgb(128, 64, 64);
            listBox4.FormattingEnabled = true;
            listBox4.ItemHeight = 37;
            listBox4.Location = new Point(3, 168);
            listBox4.Name = "listBox4";
            listBox4.Size = new Size(1525, 300);
            listBox4.TabIndex = 1;
            listBox4.SelectedIndexChanged += listBox4_SelectedIndexChanged;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1550, 692);
            Controls.Add(Mainmenu);
            Controls.Add(TransferPage);
            Controls.Add(LoginPage);
            Controls.Add(Enter_Page2);
            Controls.Add(Enter_Page);
            Controls.Add(EnterPageDeposit);
            Controls.Add(Withdraw);
            Controls.Add(TransferAlert);
            Controls.Add(TransferPage2);
            Controls.Add(DepositPage);
            Controls.Add(DepositAlert);
            Controls.Add(CheckPage);
            Controls.Add(InsufficientAlert);
            Controls.Add(CollectAlert);
            Controls.Add(AlertBalance);
            Controls.Add(BalanceAlert);
            Controls.Add(LoginAlert);
            Controls.Add(AlertPage);
            Controls.Add(LogoutConformation);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Form1";
            Text = "Form1";
            WindowState = FormWindowState.Maximized;
            LoginPage.ResumeLayout(false);
            LoginPage.PerformLayout();
            Credentials.ResumeLayout(false);
            Credentials.PerformLayout();
            Mainmenu.ResumeLayout(false);
            Mainmenu.PerformLayout();
            Withdraw.ResumeLayout(false);
            Withdraw.PerformLayout();
            AlertPage.ResumeLayout(false);
            AlertPage.PerformLayout();
            Enter_Page.ResumeLayout(false);
            Clear_Page.ResumeLayout(false);
            Backspace_Page.ResumeLayout(false);
            Num_Page.ResumeLayout(false);
            Num1Page.ResumeLayout(false);
            Num2Page.ResumeLayout(false);
            Entering.ResumeLayout(false);
            Entering.PerformLayout();
            InsufficientAlert.ResumeLayout(false);
            InsufficientAlert.PerformLayout();
            AlertBalance.ResumeLayout(false);
            AlertBalance.PerformLayout();
            CollectAlert.ResumeLayout(false);
            CollectAlert.PerformLayout();
            TransferPage.ResumeLayout(false);
            TransferPage.PerformLayout();
            DepositPage.ResumeLayout(false);
            DepositPage.PerformLayout();
            CheckPage.ResumeLayout(false);
            CheckPage.PerformLayout();
            tableLayoutPanel1.ResumeLayout(false);
            tableLayoutPanel2.ResumeLayout(false);
            BalanceAlert.ResumeLayout(false);
            BalanceAlert.PerformLayout();
            LoginAlert.ResumeLayout(false);
            LoginAlert.PerformLayout();
            LogoutConformation.ResumeLayout(false);
            tableLayoutPanel3.ResumeLayout(false);
            tableLayoutPanel4.ResumeLayout(false);
            tableLayoutPanel5.ResumeLayout(false);
            tableLayoutPanel6.ResumeLayout(false);
            tableLayoutPanel7.ResumeLayout(false);
            tableLayoutPanel8.ResumeLayout(false);
            tableLayoutPanel9.ResumeLayout(false);
            tableLayoutPanel9.PerformLayout();
            EnterPageDeposit.ResumeLayout(false);
            tableLayoutPanel11.ResumeLayout(false);
            tableLayoutPanel12.ResumeLayout(false);
            tableLayoutPanel13.ResumeLayout(false);
            tableLayoutPanel14.ResumeLayout(false);
            tableLayoutPanel15.ResumeLayout(false);
            tableLayoutPanel16.ResumeLayout(false);
            tableLayoutPanel16.PerformLayout();
            tableLayoutPanel10.ResumeLayout(false);
            DepositAlert.ResumeLayout(false);
            DepositAlert.PerformLayout();
            Enter_Page2.ResumeLayout(false);
            tableLayoutPanel18.ResumeLayout(false);
            tableLayoutPanel19.ResumeLayout(false);
            tableLayoutPanel20.ResumeLayout(false);
            tableLayoutPanel21.ResumeLayout(false);
            tableLayoutPanel22.ResumeLayout(false);
            tableLayoutPanel23.ResumeLayout(false);
            tableLayoutPanel23.PerformLayout();
            TransferAlert.ResumeLayout(false);
            TransferAlert.PerformLayout();
            TransferPage2.ResumeLayout(false);
            TransferPage2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private TableLayoutPanel LoginPage;
        private Label WelcomeLabel;
        private TableLayoutPanel Credentials;
        private Button Login_B;
        private Label Customer_L;
        private Label Pin_L;
        private TextBox CustomerT;
        private TextBox PinT;
        private TableLayoutPanel Mainmenu;
        private Label Services_L;
        private Button Withdraw_B;
        private Button Deposit_B;
        private Button Transfer_B;
        private Button Check_B;
        private Button Logout_B;
        private TableLayoutPanel Withdraw;
        private Label accSelect_L;
        private ListBox accList;
        private Button return_B;
        private TableLayoutPanel AlertPage;
        private Button Continue_B;
        private Label Alert_L;
        private TableLayoutPanel Enter_Page;
        private TableLayoutPanel Num_Page;
        private TableLayoutPanel Entering;
        private TableLayoutPanel Clear_Page;
        private Button b_1;
        private TableLayoutPanel Num2Page;
        private Button b_0;
        private Button button3;
        private Button button4;
        private Button button5;
        private Button button6;
        private TableLayoutPanel Num1Page;
        private Button button7;
        private Button button8;
        private Button button9;
        private Button button2;
        private Label EnterAmt_L;
        private TextBox EnterAmt_T;
        private Button Continue2_B;
        private TableLayoutPanel Backspace_Page;
        private Button Backspace_B;
        private Button Clear_B;
        private Button Return2_B;
        private TableLayoutPanel InsufficientAlert;
        private Button Continue_3B;
        private Label label1;
        private TableLayoutPanel AlertBalance;
        private Label label2;
        private Button Return3_B;
        private TableLayoutPanel CollectAlert;
        private Button Continue4_B;
        private Label label3;
        private TableLayoutPanel TransferPage;
        private ListBox listBox1;
        private Button Return4_B;
        private Label label4;
        private TableLayoutPanel DepositPage;
        private ListBox listBox2;
        private Button Return5_B;
        private Label label5;
        private TableLayoutPanel CheckPage;
        private ListBox listBox3;
        private Button Return6_B;
        private Label label6;
        private TableLayoutPanel tableLayoutPanel1;
        private Button button1;
        private Label label7;
        private TableLayoutPanel tableLayoutPanel2;
        private Button button10;
        private Label label8;
        private TableLayoutPanel BalanceAlert;
        private Button Return7_B;
        private Label label9;
        private TableLayoutPanel LoginAlert;
        private Button Continue5_B;
        private Label label10;
        private TableLayoutPanel LogoutConformation;
        private Button Cancel_B;
        private Button Exit_B;
        private TableLayoutPanel tableLayoutPanel3;
        private TableLayoutPanel tableLayoutPanel4;
        private Button button11;
        private TableLayoutPanel tableLayoutPanel5;
        private Button button12;
        private Button button13;
        private Button button14;
        private TableLayoutPanel tableLayoutPanel6;
        private TableLayoutPanel tableLayoutPanel7;
        private Button button15;
        private Button button16;
        private Button button17;
        private Button button18;
        private Button button19;
        private TableLayoutPanel tableLayoutPanel8;
        private Button button20;
        private Button button21;
        private Button button22;
        private Button button23;
        private Button button24;
        private TableLayoutPanel tableLayoutPanel9;
        private Label label11;
        private TextBox textBox1;
        private TableLayoutPanel EnterPageDeposit;
        private TableLayoutPanel tableLayoutPanel11;
        private Button button25;
        private TableLayoutPanel tableLayoutPanel12;
        private Button button26;
        private Button button27;
        private Button button28;
        private TableLayoutPanel tableLayoutPanel13;
        private TableLayoutPanel tableLayoutPanel14;
        private Button button29;
        private Button button30;
        private Button button31;
        private Button button32;
        private Button button33;
        private TableLayoutPanel tableLayoutPanel15;
        private Button button34;
        private Button button35;
        private Button button36;
        private Button button37;
        private Button button38;
        private TableLayoutPanel tableLayoutPanel16;
        private Label label12;
        private TextBox textBox2;
        private TableLayoutPanel tableLayoutPanel10;
        private Button button39;
        private Label label13;
        private TableLayoutPanel DepositAlert;
        private Button Return_Deposit;
        private Label label14;
        private TableLayoutPanel Enter_Page2;
        private TableLayoutPanel tableLayoutPanel18;
        private Button button40;
        private TableLayoutPanel tableLayoutPanel19;
        private Button button41;
        private Button button42;
        private Button button43;
        private TableLayoutPanel tableLayoutPanel20;
        private TableLayoutPanel tableLayoutPanel21;
        private Button button44;
        private Button button45;
        private Button button46;
        private Button button47;
        private Button button48;
        private TableLayoutPanel tableLayoutPanel22;
        private Button button49;
        private Button button50;
        private Button button51;
        private Button button52;
        private Button button53;
        private TableLayoutPanel tableLayoutPanel23;
        private Label label15;
        private TextBox textBox3;
        private TableLayoutPanel TransferAlert;
        private Button button54;
        private Label label16;
        private TableLayoutPanel TransferPage2;
        private Button button55;
        private Label label17;
        private ListBox listBox4;
    }
}
