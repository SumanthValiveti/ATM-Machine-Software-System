using System.Collections;
using WindowsFormsApp1;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using MySql.Data.MySqlClient;
namespace ATM_New
{
    public partial class Form1 : Form
    {
        Customer currentCustomer = new Customer(1);
        ArrayList accountList = new ArrayList();
        Account selectedAccount;
        double machineCash = 100000;
        int withdrawCode = -1;
        int depositCode = -1;
        int transferCode = -1;
        public Form1()
        {
            InitializeComponent();
            accountList = Account.retrieveAccounts(currentCustomer.getID());
        }

        private void Label1_Click(object sender, EventArgs e)
        {

        }

        private void Login_B_Click(object sender, EventArgs e)
        {
            int id = int.Parse(CustomerT.Text);
            int pin = int.Parse(PinT.Text);

            Customer customer = new Customer(id, pin);
            try
            {
                if (customer.Login())
                {
                    LoginPage.Visible = false;
                    Mainmenu.Visible = true;
                }
                else
                {
                    // MessageBox.Show("Alert!" +"            "+
                    //   "Check your CustomerId or PIN ");
                    label10.Text = "Alert!\n" + "\n" +
                        "Check your CustomerId or PIN";
                    LoginPage.Visible = false;
                    LoginAlert.Visible = true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }

        private void TableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Label1_Click_1(object sender, EventArgs e)
        {

        }

        private void Withdraw_B_Click(object sender, EventArgs e)
        {
            accList.Items.Clear();
            Account tempAccount;
            Console.WriteLine("number of account: " + accountList.Count);
            for (int i = 0; i < accountList.Count; i++)
            {
                tempAccount = (Account)accountList[i];
                accList.Items.Add("                                                                                                                              " + tempAccount.getAccountNum());
            }
            Mainmenu.Visible = false;
            Withdraw.Visible = true;
        }

        private void Deposit_B_Click(object sender, EventArgs e)
        {
            listBox2.Items.Clear();
            Account tempAccount;
            Console.WriteLine("number of account: " + accountList.Count);
            for (int i = 0; i < accountList.Count; i++)
            {
                tempAccount = (Account)accountList[i];
                listBox2.Items.Add("                                                                                                                              " + tempAccount.getAccountNum());
            }
            Mainmenu.Visible = false;
            DepositPage.Visible = true;
        }

        private void Transfer_B_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            Account tempAccount;
            Console.WriteLine("number of account: " + accountList.Count);
            for (int i = 0; i < accountList.Count; i++)
            {
                tempAccount = (Account)accountList[i];
                listBox1.Items.Add("                                                                                                                              " + tempAccount.getAccountNum());
            }
            Mainmenu.Visible = false;
            TransferPage.Visible = true;

        }

        private void Check_B_Click(object sender, EventArgs e)
        {
            listBox3.Items.Clear();
            Account tempAccount;
            Console.WriteLine("number of account: " + accountList.Count);
            for (int i = 0; i < accountList.Count; i++)
            {
                tempAccount = (Account)accountList[i];
                listBox3.Items.Add("                                                                                                                              " + tempAccount.getAccountNum());
            }
            Mainmenu.Visible = false;
            CheckPage.Visible = true;
        }

        private void Logout_B_Click(object sender, EventArgs e)
        {
            Mainmenu.Visible = false;
            LogoutConformation.Visible = true;
        }

        private void Exit_B_Click(object sender, EventArgs e)
        {
            LogoutConformation.Visible = false;
            LoginPage.Visible = true;
        }

        private void return_B_Click(object sender, EventArgs e)
        {
            Mainmenu.Visible = true;
            Withdraw.Visible = false;
        }

        private void Return7_B_Click(object sender, EventArgs e)
        {

            CheckPage.Visible = false;
            Mainmenu.Visible = true;
        }

        private void Return4_B_Click(object sender, EventArgs e)
        {
            Mainmenu.Visible = true;
            TransferPage.Visible = false;
        }

        private void Return5_B_Click(object sender, EventArgs e)
        {
            Mainmenu.Visible = true;
            DepositPage.Visible = false;
        }

        private void Return6_B_Click(object sender, EventArgs e)
        {
            Mainmenu.Visible = true;
            CheckPage.Visible = false;
        }

        private void Cancel_B_Click(object sender, EventArgs e)
        {
            LogoutConformation.Visible = false;
            Mainmenu.Visible = true;
        }

        private void accList_SelectedIndexChanged(object sender, EventArgs e)
        {
            selectedAccount = (Account)accountList[accList.SelectedIndex];
            if (selectedAccount.checkDailyTransaction() == false)
            {
                withdrawCode = 1;
                label1.Text = "Alert!!\n"+"The transactions of this account have exceeded the max limit $3000 for today.\n" + "\n"
                     + "Please select another account.";
                Withdraw.Visible = false;
                InsufficientAlert.Visible = true;
            }
            else
            {
                EnterAmt_T.Text = "0";
                Withdraw.Visible = false;
                Enter_Page.Visible = true;
            }
        }

        private void Clear_B_Click(object sender, EventArgs e)
        {
            EnterAmt_T.Text = "0";
        }

        private void Return2_B_Click(object sender, EventArgs e)
        {
            Enter_Page.Visible = false;
            Withdraw.Visible = true;
        }

        private void Continue2_B_Click(object sender, EventArgs e)
        {
            double amount = Double.Parse(EnterAmt_T.Text);
            withdrawCode = selectedAccount.withdrawMoney(amount, machineCash);
            if (withdrawCode == 0)
            {
                label1.Text = "Please Collect Your Cash.\n Transaction number: " + "\n" +
                    +selectedAccount.getNewTransaction().getTransNum() + "\n" + "Withdrawal amount: $"
                    + selectedAccount.getNewTransaction().getAmount() + "\n" + "From account: "
                    + selectedAccount.getAccountNum();
            }
            else if (withdrawCode == 1)
            {
                label1.Text = "Alert!!\n" + "The transactions of this account have exceeded the max limit $3000 for today.\n" + "\n"
                    + "Please select another account.";
            }
            else if (withdrawCode == 2)
            {
                label1.Text = "Alert!!\n" + "The amount will make the transactions of this account exceed the max limit $3000 for today.\n" + "\n"
                    + "Please enter a smaller amount.";
            }
            else if (withdrawCode == 3)
            {
                label1.Text = "Insufficient Funds!!\n" + "The amount you entered is greater than the balance of the selected account.\n" + "\n"
                    + "Please enter a smaller amount.";
            }
            else if (withdrawCode == 4)
            {
                label1.Text = "Sorry for Inconvinence!!!\n" + "The machince doesn't have enough cash for your withdrawal.\n" + "\n"
                    + "Please enter a smaller amount.";
            }
            Enter_Page.Visible = false;
            InsufficientAlert.Visible = true;
        }

        private void Backspace_B_Click(object sender, EventArgs e)
        {
            if (EnterAmt_T.TextLength == 1)
                EnterAmt_T.Text = "0";
            else
                EnterAmt_T.Text = EnterAmt_T.Text.Substring(0, EnterAmt_T.TextLength - 1);
        }

        private void b_0_Click(object sender, EventArgs e)
        {
            if (EnterAmt_T.Text != "0" && EnterAmt_T.TextLength <= 3)
                EnterAmt_T.Text = EnterAmt_T.Text + "0";
        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (EnterAmt_T.Text == "0")
                EnterAmt_T.Text = "9";
            else if (EnterAmt_T.TextLength <= 3)
                EnterAmt_T.Text = EnterAmt_T.Text + "9";
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (EnterAmt_T.Text == "0")
                EnterAmt_T.Text = "8";
            else if (EnterAmt_T.TextLength <= 3)
                EnterAmt_T.Text = EnterAmt_T.Text + "8";
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (EnterAmt_T.Text == "0")
                EnterAmt_T.Text = "7";
            else if (EnterAmt_T.TextLength <= 3)
                EnterAmt_T.Text = EnterAmt_T.Text + "7";
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (EnterAmt_T.Text == "0")
                EnterAmt_T.Text = "6";
            else if (EnterAmt_T.TextLength <= 3)
                EnterAmt_T.Text = EnterAmt_T.Text + "6";
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (EnterAmt_T.Text == "0")
                EnterAmt_T.Text = "5";
            else if (EnterAmt_T.TextLength <= 3)
                EnterAmt_T.Text = EnterAmt_T.Text + "5";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (EnterAmt_T.Text == "0")
                EnterAmt_T.Text = "4";
            else if (EnterAmt_T.TextLength <= 3)
                EnterAmt_T.Text = EnterAmt_T.Text + "4";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (EnterAmt_T.Text == "0")
                EnterAmt_T.Text = "3";
            else if (EnterAmt_T.TextLength <= 3)
                EnterAmt_T.Text = EnterAmt_T.Text + "3";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (EnterAmt_T.Text == "0")
                EnterAmt_T.Text = "2";
            else if (EnterAmt_T.TextLength <= 3)
                EnterAmt_T.Text = EnterAmt_T.Text + "2";
        }

        private void b_1_Click(object sender, EventArgs e)
        {
            if (EnterAmt_T.Text == "0")
                EnterAmt_T.Text = "1";
            else if (EnterAmt_T.TextLength <= 3)
                EnterAmt_T.Text = EnterAmt_T.Text + "1";
        }

        private void Continue_3B_Click(object sender, EventArgs e)
        {
            InsufficientAlert.Visible = false;
            if (withdrawCode == 1)
                Withdraw.Visible = true;
            else if (withdrawCode == 2)
                Enter_Page.Visible = true;
            else if (withdrawCode == 3)
                Enter_Page.Visible = true;
            else if (withdrawCode == 4)
                Enter_Page.Visible = true;
            else
                Mainmenu.Visible = true;
            withdrawCode = -1;
        }

        private void Continue5_B_Click(object sender, EventArgs e)
        {
            LoginPage.Visible = true;
            LoginAlert.Visible = false;
        }

        private void listBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            selectedAccount = (Account)accountList[listBox3.SelectedIndex];
            // Assuming you have an instance of the Account class named selectedAccount
            double balance = selectedAccount.getBalance();

            label2.Text = "Total Balance:\n" + "\n$"
                     + balance;
            CheckPage.Visible = false;
            AlertBalance.Visible = true;
        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void Return3_B_Click(object sender, EventArgs e)
        {
            Mainmenu.Visible = true;
            AlertBalance.Visible = false;
        }

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            selectedAccount = (Account)accountList[listBox2.SelectedIndex];
            if (selectedAccount.checkDailyTransaction() == false)
            {
                depositCode = 1;
                label14.Text = "Alert!!\n" + "The transactions of this account have exceeded the max limit $3000 for today.\n" + "\n"
                     + "Please select another account.";
                DepositPage.Visible = false;
                DepositAlert.Visible = true;
            }
            else
            {
                textBox2.Text = "0";
                DepositPage.Visible = false;
                EnterPageDeposit.Visible = true;
            }
        }


        private void button26_Click(object sender, EventArgs e)
        {
            if (textBox2.TextLength == 1)
                textBox2.Text = "0";
            else
                textBox2.Text = textBox2.Text.Substring(0, textBox2.TextLength - 1);
        }

        private void button27_Click(object sender, EventArgs e)
        {
            textBox2.Text = "0";
        }

        private void button28_Click(object sender, EventArgs e)
        {
            DepositPage.Visible = true;
            EnterPageDeposit.Visible = false;
        }

        private void button25_Click(object sender, EventArgs e)
        {
            double amount = Double.Parse(textBox2.Text);
            depositCode = selectedAccount.depositMoney(amount, machineCash);
            if (depositCode == 0)
            {
                label14.Text = "Amount is Deposited Successfully!.\n Transaction number: "
                    + selectedAccount.getNewTransaction().getTransNum() + "\n" + "Deposit amount: $"
                    + selectedAccount.getNewTransaction().getAmount() + "\n" + "To account: "
                    + selectedAccount.getAccountNum();
            }
            else if (depositCode == 1)
            {
                label14.Text = "Alert!!\n" + "The transactions of this account have exceeded the max limit $3000 for today.\n" + "\n"
                    + "Please select another account.";
            }
            else if (depositCode == 2)
            {
                label14.Text = "Alert!!\n" + "The amount will make the transactions of this account exceed the max limit $3000 for today.\n" + "\n"
                    + "Please enter a smaller amount.";
            }

            EnterPageDeposit.Visible = false;
            DepositAlert.Visible = true;
        }

        private void Return_Deposit_Click(object sender, EventArgs e)
        {
            DepositAlert.Visible = false;
            if (depositCode == 1)
                DepositPage.Visible = true;
            else if (depositCode == 2)
                EnterPageDeposit.Visible = true;
            else
                Mainmenu.Visible = true;
            depositCode = -1;
        }


        private void button33_Click_2(object sender, EventArgs e)
        {
            if (textBox2.Text == "0")
                textBox2.Text = "1";
            else if (textBox2.TextLength <= 3)
                textBox2.Text = textBox2.Text + "1";
        }

        private void button32_Click_1(object sender, EventArgs e)
        {
            if (textBox2.Text == "0")
                textBox2.Text = "2";
            else if (textBox2.TextLength <= 3)
                textBox2.Text = textBox2.Text + "2";
        }

        private void button31_Click_1(object sender, EventArgs e)
        {
            if (textBox2.Text == "0")
                textBox2.Text = "3";
            else if (textBox2.TextLength <= 3)
                textBox2.Text = textBox2.Text + "3";
        }

        private void button30_Click_1(object sender, EventArgs e)
        {
            if (textBox2.Text == "0")
                textBox2.Text = "4";
            else if (textBox2.TextLength <= 3)
                textBox2.Text = textBox2.Text + "4";
        }

        private void button29_Click_1(object sender, EventArgs e)
        {
            if (textBox2.Text == "0")
                textBox2.Text = "5";
            else if (textBox2.TextLength <= 3)
                textBox2.Text = textBox2.Text + "5";
        }

        private void button38_Click_1(object sender, EventArgs e)
        {
            if (textBox2.Text == "0")
                textBox2.Text = "6";
            else if (textBox2.TextLength <= 3)
                textBox2.Text = textBox2.Text + "6";
        }

        private void button37_Click_1(object sender, EventArgs e)
        {
            if (textBox2.Text == "0")
                textBox2.Text = "7";
            else if (textBox2.TextLength <= 3)
                textBox2.Text = textBox2.Text + "7";
        }

        private void button36_Click_1(object sender, EventArgs e)
        {
            if (textBox2.Text == "0")
                textBox2.Text = "8";
            else if (textBox2.TextLength <= 3)
                textBox2.Text = textBox2.Text + "8";
        }

        private void button35_Click_1(object sender, EventArgs e)
        {
            if (textBox2.Text == "0")
                textBox2.Text = "9";
            else if (textBox2.TextLength <= 3)
                textBox2.Text = textBox2.Text + "9";
        }

        private void button34_Click(object sender, EventArgs e)
        {
            if (textBox2.Text == "0")
                textBox2.Text = "0";
            else if (textBox2.TextLength <= 3)
                textBox2.Text = textBox2.Text + "0";
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            selectedAccount = (Account)accountList[listBox1.SelectedIndex];
            if (selectedAccount.checkDailyTransaction() == false)
            {
                transferCode = 1;
                label16.Text = "Alert!!\n" + "The transactions of this account have exceeded the max limit $3000 for today.\n" + "\n"
                     + "Please select another account.";
                TransferPage.Visible = false;
                TransferAlert.Visible = true;
            }
            else
            {
                listBox4.Items.Clear();
                foreach (Account tempAccount in accountList)
                {
                    if (tempAccount != selectedAccount) 
                    {
                        listBox4.Items.Add("                                                                                                                              " + tempAccount.getAccountNum().ToString());
                        Console.WriteLine("Account Number: " + tempAccount.getAccountNum());
                    }
                }
                textBox3.Text = "0";
                TransferPage.Visible = false;
                TransferPage2.Visible = true;
            }
        }

        private void button43_Click(object sender, EventArgs e)
        {
            TransferPage.Visible = true;
            Enter_Page2.Visible = false;
        }

        private void button48_Click(object sender, EventArgs e)
        {
            if (textBox3.Text == "0")
                textBox3.Text = "1";
            else if (textBox3.TextLength <= 3)
                textBox3.Text = textBox3.Text + "1";
        }

        private void button47_Click(object sender, EventArgs e)
        {
            if (textBox3.Text == "0")
                textBox3.Text = "2";
            else if (textBox3.TextLength <= 3)
                textBox3.Text = textBox3.Text + "2";
        }

        private void button46_Click(object sender, EventArgs e)
        {
            if (textBox3.Text == "0")
                textBox3.Text = "3";
            else if (textBox3.TextLength <= 3)
                textBox3.Text = textBox3.Text + "3";
        }

        private void button45_Click(object sender, EventArgs e)
        {
            if (textBox3.Text == "0")
                textBox3.Text = "4";
            else if (textBox3.TextLength <= 3)
                textBox3.Text = textBox3.Text + "4";
        }

        private void button44_Click(object sender, EventArgs e)
        {
            if (textBox3.Text == "0")
                textBox3.Text = "5";
            else if (textBox3.TextLength <= 3)
                textBox3.Text = textBox3.Text + "5";
        }

        private void button53_Click(object sender, EventArgs e)
        {
            if (textBox3.Text == "0")
                textBox3.Text = "6";
            else if (textBox3.TextLength <= 3)
                textBox3.Text = textBox3.Text + "6";
        }

        private void button52_Click(object sender, EventArgs e)
        {
            if (textBox3.Text == "0")
                textBox3.Text = "7";
            else if (textBox3.TextLength <= 3)
                textBox3.Text = textBox3.Text + "7";
        }

        private void button51_Click(object sender, EventArgs e)
        {
            if (textBox3.Text == "0")
                textBox3.Text = "8";
            else if (textBox3.TextLength <= 3)
                textBox3.Text = textBox3.Text + "8";
        }

        private void button50_Click(object sender, EventArgs e)
        {
            if (textBox3.Text == "0")
                textBox3.Text = "9";
            else if (textBox3.TextLength <= 3)
                textBox3.Text = textBox3.Text + "9";
        }

        private void button49_Click(object sender, EventArgs e)
        {
            if (textBox3.Text == "0")
                textBox3.Text = "0";
            else if (textBox3.TextLength <= 3)
                textBox3.Text = textBox3.Text + "0";
        }

        private void button41_Click(object sender, EventArgs e)
        {
            if (textBox3.TextLength == 1)
                textBox3.Text = "0";
            else
                textBox3.Text = textBox3.Text.Substring(0, textBox3.TextLength - 1);
        }

        private void button42_Click(object sender, EventArgs e)
        {
            textBox3.Text = "0";
        }

        private void button40_Click(object sender, EventArgs e)
        {
            double amount = Double.Parse(textBox3.Text);
            transferCode = selectedAccount.transferMoney(amount, machineCash);
            if (transferCode == 0)
            {
                label16.Text = "Amount is Successfully Transfered!!!\n Transaction number: "
                    + selectedAccount.getNewTransaction().getTransNum() + "\n" + "Transfer amount: $"
                    + selectedAccount.getNewTransaction().getAmount() + "\n" + "From account: "
                    + selectedAccount.getAccountNum();
            }
            else if (transferCode == 1)
            {
                label16.Text = "Alert!!\n" + "The transactions of this account have exceeded the max limit $3000 for today.\n" + "\n"
                    + "Please select another account.";
            }
            else if (transferCode == 2)
            {
                label16.Text = "Alert!!\n" + "The amount will make the transactions of this account exceed the max limit $3000 for today.\n" + "\n"
                    + "Please enter a smaller amount.";
            }
            else if (transferCode == 3)
            {
                label16.Text = "Insufficient Funds!!!\n" + "The amount you entered is greater than the balance of the selected account.\n" + "Or\n"
                    + "Please enter a smaller amount.";
            }
            Enter_Page2.Visible = false;
            TransferAlert.Visible = true;
        }

        private void button54_Click(object sender, EventArgs e)
        {
            TransferAlert.Visible = false;
            if (transferCode == 1)
                TransferPage.Visible = true;
            else if (transferCode == 2)
                Enter_Page2.Visible = true;
            else if (transferCode == 3)
                Enter_Page2.Visible = true;
            else
                Mainmenu.Visible = true;
            transferCode = -1;
        }

        private void label17_Click(object sender, EventArgs e)
        {

        }

        private void listBox4_SelectedIndexChanged(object sender, EventArgs e)
        {
            TransferPage2.Visible = false;
            Enter_Page2.Visible = true;
        }

        private void button55_Click(object sender, EventArgs e)
        {
            TransferPage.Visible = true;
            TransferPage2.Visible = false;
        }

        private void EnterAmt_L_Click(object sender, EventArgs e)
        {

        }
    }
}
